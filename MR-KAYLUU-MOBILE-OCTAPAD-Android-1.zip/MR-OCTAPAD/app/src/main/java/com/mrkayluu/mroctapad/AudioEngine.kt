package com.mrkayluu.mroctapad

import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioFocusRequest
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.os.Build
import android.os.Process
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File
import java.io.InputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.min

data class AudioOutputOption(
    val id: Int,
    val name: String,
    val typeLabel: String
)

data class AudioHardwareCapabilities(
    val nativeSampleRate: Int,
    val nativeFramesPerBuffer: Int,
    val supportedSampleRates: List<Int>,
    val supportsLowLatency: Boolean,
    val supportsProAudio: Boolean,
    val supportsMultitouchDistinct: Boolean,
    val activeSampleRate: Int,
    val activeBufferFrames: Int,
    val outputDevices: List<AudioOutputOption>
)

class AudioEngine(
    private val context: Context,
    private val storageManager: StorageManager,
    private val effectsProcessor: EffectsProcessor,
    private val equalizerManager: EqualizerManager
) {
    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    private val _qualitySettings = MutableStateFlow(storageManager.loadQuality())
    val qualitySettings: StateFlow<QualitySettings> = _qualitySettings.asStateFlow()

    private val _capabilities = MutableStateFlow(queryHardwareCapabilities(_qualitySettings.value))
    val capabilities: StateFlow<AudioHardwareCapabilities> = _capabilities.asStateFlow()

    private val _activeVoiceCount = MutableStateFlow(0)
    val activeVoiceCount: StateFlow<Int> = _activeVoiceCount.asStateFlow()

    private class PcmSample(
        val data: FloatArray,
        val sampleRate: Int
    )

    private class ActiveVoice {
        @Volatile var active = false
        var sample: PcmSample? = null
        var position = 0.0
        var gain = 1.0f
        var pitchRatio = 1.0
        var startSeq = 0L
    }

    private val maxVoices = 24
    private val voices = Array(maxVoices) { ActiveVoice() }
    private val voiceLock = Any()
    private var sequenceCounter = 0L

    private val bundledSamples = ConcurrentHashMap<String, PcmSample>()
    private val customSamples = ConcurrentHashMap<String, PcmSample>()

    private val isRunning = AtomicBoolean(false)
    private val hasAudioFocus = AtomicBoolean(false)
    private var audioThread: Thread? = null
    private var audioTrack: AudioTrack? = null
    private var focusRequest: AudioFocusRequest? = null

    private val rawSampleResMap = mapOf(
        "pad_kick" to R.raw.pad_kick,
        "pad_snare" to R.raw.pad_snare,
        "pad_hihat_closed" to R.raw.pad_hihat_closed,
        "pad_hihat_open" to R.raw.pad_hihat_open,
        "pad_tom_low" to R.raw.pad_tom_low,
        "pad_tom_high" to R.raw.pad_tom_high,
        "pad_crash" to R.raw.pad_crash,
        "pad_clap" to R.raw.pad_clap,
        "pad_dhol_bass" to R.raw.pad_dhol_bass,
        "pad_dhol_treble" to R.raw.pad_dhol_treble,
        "pad_dholak_ge" to R.raw.pad_dholak_ge,
        "pad_dholak_na" to R.raw.pad_dholak_na,
        "pad_tabla_ge" to R.raw.pad_tabla_ge,
        "pad_tabla_na" to R.raw.pad_tabla_na,
        "pad_timli" to R.raw.pad_timli,
        "pad_nagada" to R.raw.pad_nagada,
        "pad_conga" to R.raw.pad_conga,
        "pad_rimshot" to R.raw.pad_rimshot
    )

    private val focusChangeListener = AudioManager.OnAudioFocusChangeListener { change ->
        when (change) {
            AudioManager.AUDIOFOCUS_LOSS,
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> {
                hasAudioFocus.set(false)
                audioTrack?.pause()
            }
            AudioManager.AUDIOFOCUS_GAIN -> {
                hasAudioFocus.set(true)
                audioTrack?.play()
            }
        }
    }

    fun initialize() {
        preloadBundledSamples()
        loadAllImportedSamples()
        startEngine()
    }

    private fun preloadBundledSamples() {
        rawSampleResMap.forEach { (key, resId) ->
            if (!bundledSamples.containsKey(key)) {
                context.resources.openRawResource(resId).use { stream ->
                    parseWavStream(stream)?.let { bundledSamples[key] = it }
                }
            }
        }
    }

    fun loadAllImportedSamples() {
        val dir = storageManager.importedSoundsDir
        storageManager.loadImportedSounds().forEach { sound ->
            val file = sound.filePath.takeIf { it.isNotBlank() }?.let { File(it) }
                ?.takeIf { it.exists() }
                ?: File(dir, sound.fileName)
            if (file.exists() && !customSamples.containsKey(sound.id)) {
                decodeAudioFile(file)?.let { customSamples[sound.id] = it }
            }
        }
    }

    fun registerDecodedCustomSound(soundId: String, file: File): Long {
        val decoded = decodeAudioFile(file) ?: return 0L
        customSamples[soundId] = decoded
        return ((decoded.data.size.toDouble() / decoded.sampleRate) * 1000.0).toLong().coerceAtLeast(1L)
    }

    fun registerDecodedCustomSoundResult(soundId: String, file: File): Result<Long> {
        if (!file.exists() || file.length() <= 0L) {
            return Result.failure(IllegalArgumentException("Imported audio file is empty."))
        }
        val decoded = decodeAudioFile(file)
            ?: return Result.failure(IllegalStateException("Unsupported or corrupted audio stream. Please choose a valid WAV, MP3, or OGG file."))
        if (decoded.data.isEmpty() || decoded.sampleRate <= 0) {
            return Result.failure(IllegalStateException("Audio file contains no playable PCM frames."))
        }
        customSamples[soundId] = decoded
        val durationMs = ((decoded.data.size.toDouble() / decoded.sampleRate) * 1000.0).toLong().coerceAtLeast(1L)
        return Result.success(durationMs)
    }

    fun triggerPad(
        sampleKey: String,
        customSoundId: String?,
        padVolume: Float,
        padPitch: Float,
        velocity: Float = 1.0f
    ) {
        val sample = if (customSoundId != null) {
            customSamples[customSoundId] ?: bundledSamples[sampleKey]
        } else {
            bundledSamples[sampleKey]
        } ?: return

        val globalPitch = effectsProcessor.settings.value.pitchMultiplier
        val targetRate = _capabilities.value.activeSampleRate.toDouble()
        val rateRatio = (sample.sampleRate / targetRate) * padPitch.toDouble() * globalPitch.toDouble()
        val combinedGain = (padVolume * velocity).coerceIn(0f, 1.5f)

        synchronized(voiceLock) {
            var slot = voices.firstOrNull { !it.active }
            if (slot == null) {
                slot = voices.minByOrNull { it.startSeq } ?: voices[0]
            }
            slot.sample = sample
            slot.position = 0.0
            slot.gain = combinedGain
            slot.pitchRatio = rateRatio.coerceIn(0.25, 4.0)
            slot.startSeq = ++sequenceCounter
            slot.active = true
        }
    }

    fun previewCustomSound(soundId: String) {
        val sample = customSamples[soundId] ?: return
        val targetRate = _capabilities.value.activeSampleRate.toDouble()
        synchronized(voiceLock) {
            val slot = voices.firstOrNull { !it.active } ?: voices.minByOrNull { it.startSeq } ?: voices[0]
            slot.sample = sample
            slot.position = 0.0
            slot.gain = 0.95f
            slot.pitchRatio = (sample.sampleRate / targetRate).coerceIn(0.25, 4.0)
            slot.startSeq = ++sequenceCounter
            slot.active = true
        }
    }

    fun updateQualitySettings(transform: (QualitySettings) -> QualitySettings) {
        val next = transform(_qualitySettings.value)
        _qualitySettings.value = next
        storageManager.saveQuality(next)
        stopEngine()
        startEngine()
    }

    fun refreshCapabilities() {
        _capabilities.value = queryHardwareCapabilities(_qualitySettings.value)
    }

    fun onPause() {
        audioTrack?.pause()
    }

    fun onResume() {
        requestFocus()
        if (isRunning.get()) {
            audioTrack?.play()
        } else {
            startEngine()
        }
    }

    fun release() {
        stopEngine()
        abandonFocus()
    }

    private fun startEngine() {
        if (isRunning.get()) return
        val q = _qualitySettings.value
        val hw = queryHardwareCapabilities(q)
        val sampleRate = hw.activeSampleRate
        val framesPerWrite = hw.activeBufferFrames

        val minBytes = AudioTrack.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )
        val desiredBytes = framesPerWrite * 2 * 2
        val bufferBytes = maxOf(minBytes, desiredBytes)

        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
            .build()

        val format = AudioFormat.Builder()
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(sampleRate)
            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
            .build()

        val trackBuilder = AudioTrack.Builder()
            .setAudioAttributes(attrs)
            .setAudioFormat(format)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .setBufferSizeInBytes(bufferBytes)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val mode = if (q.lowLatencyPreferred) {
                AudioTrack.PERFORMANCE_MODE_LOW_LATENCY
            } else {
                AudioTrack.PERFORMANCE_MODE_NONE
            }
            trackBuilder.setPerformanceMode(mode)
        }

        val track = trackBuilder.build()

        if (q.preferredOutputDeviceId != -1) {
            val targetDevice = audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
                .firstOrNull { it.id == q.preferredOutputDeviceId }
            if (targetDevice != null) {
                track.setPreferredDevice(targetDevice)
            }
        }

        audioTrack = track
        _capabilities.value = hw
        requestFocus()
        track.play()

        isRunning.set(true)
        audioThread = Thread({
            Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
            val mixBuffer = FloatArray(framesPerWrite)
            val pcmOut = ShortArray(framesPerWrite)

            while (isRunning.get()) {
                mixBuffer.fill(0f)
                var activeCount = 0

                synchronized(voiceLock) {
                    for (v in voices) {
                        if (!v.active) continue
                        val smp = v.sample
                        if (smp == null) {
                            v.active = false
                            continue
                        }
                        activeCount++
                        val data = smp.data
                        val len = data.size
                        var pos = v.position
                        val step = v.pitchRatio
                        val gain = v.gain

                        for (i in 0 until framesPerWrite) {
                            val idx = pos.toInt()
                            if (idx >= len - 1) {
                                v.active = false
                                break
                            }
                            val frac = (pos - idx).toFloat()
                            val sampleVal = data[idx] + (data[idx + 1] - data[idx]) * frac
                            mixBuffer[i] += sampleVal * gain
                            pos += step
                        }
                        v.position = pos
                        if (pos >= len - 1) {
                            v.active = false
                        }
                    }
                }
                if (_activeVoiceCount.value != activeCount) {
                    _activeVoiceCount.value = activeCount
                }

                equalizerManager.processMonoBuffer(mixBuffer, framesPerWrite, sampleRate)
                effectsProcessor.processMonoBuffer(mixBuffer, framesPerWrite, sampleRate)

                for (i in 0 until framesPerWrite) {
                    val sampleVal = softLimit(mixBuffer[i])
                    pcmOut[i] = (sampleVal * 32767f).toInt().toShort()
                }

                val written = track.write(pcmOut, 0, framesPerWrite, AudioTrack.WRITE_BLOCKING)
                if (written < 0) {
                    break
                }
            }
        }, "MrOctapadAudioThread").apply { start() }
    }

    private fun softLimit(x: Float): Float {
        val threshold = 0.86f
        val absX = kotlin.math.abs(x)
        if (absX <= threshold) return x
        val excess = absX - threshold
        val compressed = threshold + (excess / (1f + excess * 3.5f)) * (1f - threshold)
        return (if (x >= 0f) compressed else -compressed).coerceIn(-1f, 1f)
    }

    private fun stopEngine() {
        isRunning.set(false)
        audioThread?.join(400)
        audioThread = null
        audioTrack?.let {
            try {
                it.pause()
                it.flush()
                it.release()
            } catch (_: Exception) {
            }
        }
        audioTrack = null
    }

    private fun requestFocus() {
        val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            .setOnAudioFocusChangeListener(focusChangeListener)
            .build()
        focusRequest = req
        val res = audioManager.requestAudioFocus(req)
        hasAudioFocus.set(res == AudioManager.AUDIOFOCUS_REQUEST_GRANTED)
    }

    private fun abandonFocus() {
        focusRequest?.let { audioManager.abandonAudioFocusRequest(it) }
    }

    private fun queryHardwareCapabilities(q: QualitySettings): AudioHardwareCapabilities {
        val nativeSr = audioManager.getProperty(AudioManager.PROPERTY_OUTPUT_SAMPLE_RATE)?.toIntOrNull() ?: 44100
        val nativeBuf = audioManager.getProperty(AudioManager.PROPERTY_OUTPUT_FRAMES_PER_BUFFER)?.toIntOrNull() ?: 256
        val pm = context.packageManager
        val lowLatency = pm.hasSystemFeature(PackageManager.FEATURE_AUDIO_LOW_LATENCY)
        val proAudio = pm.hasSystemFeature(PackageManager.FEATURE_AUDIO_PRO)
        val multitouch = pm.hasSystemFeature(PackageManager.FEATURE_TOUCHSCREEN_MULTITOUCH_DISTINCT)

        val candidates = listOf(44100, 48000, nativeSr).distinct().sorted()
        val supported = candidates.filter { sr ->
            AudioTrack.getMinBufferSize(sr, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT) > 0
        }.ifEmpty { listOf(44100) }

        val activeSr = if (q.preferredSampleRate in supported) q.preferredSampleRate else nativeSr.coerceIn(44100, 48000)
        val activeBuf = (nativeBuf * q.bufferFramesMultiplier.coerceIn(1, 8)).coerceIn(128, 4096)

        val outputs = audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS).map { dev ->
            AudioOutputOption(
                id = dev.id,
                name = dev.productName?.toString()?.takeIf { it.isNotBlank() } ?: deviceTypeName(dev.type),
                typeLabel = deviceTypeName(dev.type)
            )
        }

        return AudioHardwareCapabilities(
            nativeSampleRate = nativeSr,
            nativeFramesPerBuffer = nativeBuf,
            supportedSampleRates = supported,
            supportsLowLatency = lowLatency,
            supportsProAudio = proAudio,
            supportsMultitouchDistinct = multitouch,
            activeSampleRate = activeSr,
            activeBufferFrames = activeBuf,
            outputDevices = outputs
        )
    }

    private fun deviceTypeName(type: Int): String = when (type) {
        AudioDeviceInfo.TYPE_BUILTIN_SPEAKER -> "Built-in Speaker"
        AudioDeviceInfo.TYPE_WIRED_HEADSET, AudioDeviceInfo.TYPE_WIRED_HEADPHONES -> "Wired Headphones"
        AudioDeviceInfo.TYPE_BLUETOOTH_A2DP, AudioDeviceInfo.TYPE_BLUETOOTH_SCO -> "Bluetooth Audio"
        AudioDeviceInfo.TYPE_USB_DEVICE, AudioDeviceInfo.TYPE_USB_HEADSET -> "USB Audio"
        else -> "Audio Output"
    }

    private fun parseWavStream(stream: InputStream): PcmSample? {
        val bytes = stream.readBytes()
        if (bytes.size < 44) return null
        val bb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
        if (String(bytes, 0, 4) != "RIFF" || String(bytes, 8, 4) != "WAVE") return null

        var offset = 12
        var audioFormat = 1
        var channels = 1
        var sampleRate = 44100
        var bitsPerSample = 16
        var dataOffset = -1
        var dataSize = 0

        while (offset + 8 <= bytes.size) {
            val chunkId = String(bytes, offset, 4)
            val rawChunkSize = bb.getInt(offset + 4)
            val chunkSize = if (rawChunkSize < 0) 0 else rawChunkSize
            if (chunkId == "fmt " && offset + 24 <= bytes.size) {
                audioFormat = bb.getShort(offset + 8).toInt() and 0xFFFF
                channels = (bb.getShort(offset + 10).toInt() and 0xFFFF).coerceAtLeast(1)
                sampleRate = bb.getInt(offset + 12)
                bitsPerSample = bb.getShort(offset + 22).toInt() and 0xFFFF
            } else if (chunkId == "data") {
                dataOffset = offset + 8
                dataSize = min(chunkSize, bytes.size - dataOffset)
                break
            }
            offset += 8 + chunkSize + (chunkSize and 1)
        }

        if (dataOffset < 0 || dataSize <= 0 || sampleRate <= 0) return null
        val bytesPerSample = bitsPerSample / 8
        if (bytesPerSample <= 0) return null
        // Handle PCM (format 1: 8/16/24/32-bit) and IEEE float (format 3: 32-bit)
        if (audioFormat != 1 && !(audioFormat == 3 && bitsPerSample == 32)) return null

        val totalFrames = dataSize / (bytesPerSample * channels)
        if (totalFrames <= 0) return null
        val floats = FloatArray(totalFrames)
        var pos = dataOffset
        for (i in 0 until totalFrames) {
            var sum = 0f
            for (c in 0 until channels) {
                val sampleVal = when {
                    audioFormat == 3 && bitsPerSample == 32 -> bb.getFloat(pos)
                    bitsPerSample == 8 -> ((bytes[pos].toInt() and 0xFF) - 128) / 128f
                    bitsPerSample == 16 -> bb.getShort(pos) / 32768f
                    bitsPerSample == 24 -> {
                        val b0 = bytes[pos].toInt() and 0xFF
                        val b1 = bytes[pos + 1].toInt() and 0xFF
                        val b2 = bytes[pos + 2].toInt()
                        ((b2 shl 16) or (b1 shl 8) or b0) / 8388608f
                    }
                    bitsPerSample == 32 -> bb.getInt(pos) / 2147483648f
                    else -> 0f
                }
                sum += sampleVal
                pos += bytesPerSample
            }
            floats[i] = (sum / channels).coerceIn(-1f, 1f)
        }
        return PcmSample(floats, sampleRate)
    }

    private fun decodeAudioFile(file: File): PcmSample? {
        if (file.extension.equals("wav", ignoreCase = true)) {
            file.inputStream().use { parseWavStream(it) }?.let { return it }
        }
        val extractor = MediaExtractor()
        var codec: MediaCodec? = null
        return try {
            extractor.setDataSource(file.absolutePath)
            var trackIndex = -1
            var format: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val fmt = extractor.getTrackFormat(i)
                val mime = fmt.getString(MediaFormat.KEY_MIME) ?: ""
                if (mime.startsWith("audio/")) {
                    trackIndex = i
                    format = fmt
                    break
                }
            }
            if (trackIndex < 0 || format == null) return null
            extractor.selectTrack(trackIndex)
            val mime = format.getString(MediaFormat.KEY_MIME) ?: return null
            var sampleRate = format.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            var channelCount = format.getInteger(MediaFormat.KEY_CHANNEL_COUNT).coerceAtLeast(1)
            var pcmEncoding = AudioFormat.ENCODING_PCM_16BIT

            codec = MediaCodec.createDecoderByType(mime)
            codec.configure(format, null, null, 0)
            codec.start()

            val info = MediaCodec.BufferInfo()
            val outSamples = ArrayList<Float>(sampleRate * 2)
            var sawInputEos = false
            var sawOutputEos = false
            val maxSamples = sampleRate * 15 // Cap single percussion shot to 15s for memory safety

            while (!sawOutputEos && outSamples.size < maxSamples) {
                if (!sawInputEos) {
                    val inIdx = codec.dequeueInputBuffer(5000)
                    if (inIdx >= 0) {
                        val inBuf = codec.getInputBuffer(inIdx)!!
                        val sampleSize = extractor.readSampleData(inBuf, 0)
                        if (sampleSize < 0) {
                            codec.queueInputBuffer(inIdx, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            sawInputEos = true
                        } else {
                            codec.queueInputBuffer(inIdx, 0, sampleSize, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }

                val outIdx = codec.dequeueOutputBuffer(info, 5000)
                if (outIdx >= 0) {
                    val outBuf = codec.getOutputBuffer(outIdx)
                    if (outBuf != null && info.size > 0) {
                        outBuf.position(info.offset)
                        outBuf.limit(info.offset + info.size)
                        val ordered = outBuf.order(ByteOrder.LITTLE_ENDIAN)
                        if (pcmEncoding == AudioFormat.ENCODING_PCM_FLOAT) {
                            val floatBuf = ordered.asFloatBuffer()
                            while (floatBuf.remaining() >= channelCount && outSamples.size < maxSamples) {
                                var sum = 0f
                                for (c in 0 until channelCount) {
                                    sum += floatBuf.get()
                                }
                                outSamples.add((sum / channelCount).coerceIn(-1f, 1f))
                            }
                        } else {
                            val shortBuf = ordered.asShortBuffer()
                            while (shortBuf.remaining() >= channelCount && outSamples.size < maxSamples) {
                                var sum = 0f
                                for (c in 0 until channelCount) {
                                    sum += shortBuf.get() / 32768f
                                }
                                outSamples.add(sum / channelCount)
                            }
                        }
                    }
                    codec.releaseOutputBuffer(outIdx, false)
                    if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                        sawOutputEos = true
                    }
                } else if (outIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val newFmt = codec.outputFormat
                    if (newFmt.containsKey(MediaFormat.KEY_SAMPLE_RATE)) {
                        sampleRate = newFmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    }
                    if (newFmt.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) {
                        channelCount = newFmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT).coerceAtLeast(1)
                    }
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N && newFmt.containsKey(MediaFormat.KEY_PCM_ENCODING)) {
                        pcmEncoding = newFmt.getInteger(MediaFormat.KEY_PCM_ENCODING)
                    }
                }
            }
            if (outSamples.isEmpty()) null else PcmSample(outSamples.toFloatArray(), sampleRate)
        } catch (_: Exception) {
            null
        } finally {
            try { codec?.stop(); codec?.release() } catch (_: Exception) {}
            try { extractor.release() } catch (_: Exception) {}
        }
    }
}
