package com.mrkayluu.mroctapad

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContract
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class PadImportFeedback(
    val eventId: Long,
    val padIndex: Int?,
    val importedSound: ImportedSound?,
    val isError: Boolean,
    val message: String
)

data class PhonePatchLoadUiState(
    val isBusy: Boolean = false,
    val busyMessage: String = "",
    val stagedPreview: StagedImportPreview? = null,
    val lastMultiAudioReport: MultiAudioImportReport? = null,
    val lastCommitResult: CommitImportResult? = null,
    val errorMessage: String? = null
)

private class OpenAudioDocumentContract : ActivityResultContract<Unit, Uri?>() {
    override fun createIntent(context: Context, input: Unit): Intent {
        return Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "audio/*"
            putExtra(
                Intent.EXTRA_MIME_TYPES,
                arrayOf(
                    "audio/*",
                    "audio/wav",
                    "audio/x-wav",
                    "audio/wave",
                    "audio/vnd.wave",
                    "audio/mpeg",
                    "audio/mp3",
                    "audio/ogg",
                    "application/ogg"
                )
            )
            addFlags(
                Intent.FLAG_GRANT_READ_URI_PERMISSION or
                    Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
            )
        }
    }

    override fun parseResult(resultCode: Int, intent: Intent?): Uri? {
        return if (resultCode == Activity.RESULT_OK) intent?.data else null
    }
}

private class OpenMultipleAudioDocumentsContract(
    private val mimeTypes: Array<String>
) : ActivityResultContract<Unit, List<Uri>>() {
    override fun createIntent(context: Context, input: Unit): Intent {
        return Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            type = "audio/*"
            putExtra(Intent.EXTRA_MIME_TYPES, mimeTypes)
            addFlags(
                Intent.FLAG_GRANT_READ_URI_PERMISSION or
                    Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
            )
        }
    }

    override fun parseResult(resultCode: Int, intent: Intent?): List<Uri> {
        if (resultCode != Activity.RESULT_OK || intent == null) return emptyList()
        val results = mutableListOf<Uri>()
        intent.clipData?.let { clip ->
            for (i in 0 until clip.itemCount) {
                clip.getItemAt(i)?.uri?.let { results.add(it) }
            }
        }
        if (results.isEmpty()) {
            intent.data?.let { results.add(it) }
        }
        return results
    }
}

private class OpenSingleDocumentWithMimesContract(
    private val primaryType: String,
    private val extraMimeTypes: Array<String>
) : ActivityResultContract<Unit, Uri?>() {
    override fun createIntent(context: Context, input: Unit): Intent {
        return Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = primaryType
            putExtra(Intent.EXTRA_MIME_TYPES, extraMimeTypes)
            addFlags(
                Intent.FLAG_GRANT_READ_URI_PERMISSION or
                    Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
            )
        }
    }

    override fun parseResult(resultCode: Int, intent: Intent?): Uri? {
        return if (resultCode == Activity.RESULT_OK) intent?.data else null
    }
}

class MainActivity : ComponentActivity() {

    private lateinit var storageManager: StorageManager
    private lateinit var effectsProcessor: EffectsProcessor
    private lateinit var equalizerManager: EqualizerManager
    private lateinit var audioEngine: AudioEngine
    private lateinit var patchManager: PatchManager
    private lateinit var midiManager: MidiManager
    private lateinit var recordingManager: RecordingManager
    private lateinit var soundImportManager: SoundImportManager
    private lateinit var phonePatchImporter: PhonePatchImporter
    private lateinit var kitManager: KitManager

    private val externalPadPulseTimes = mutableStateListOf(0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L)
    private var pendingImportPadIndex: Int? = null
    private var pendingMissingFilename: String? = null
    private var padImportFeedback by mutableStateOf<PadImportFeedback?>(null)
    private var phonePatchLoadUiState by mutableStateOf(PhonePatchLoadUiState())

    private val audioFilePicker = registerForActivityResult(OpenAudioDocumentContract()) { uri ->
        val targetPad = pendingImportPadIndex
        pendingImportPadIndex = null
        if (uri != null) {
            lifecycleScope.launch {
                val res = withContext(Dispatchers.IO) { soundImportManager.importFromUri(uri) }
                res.onSuccess { snd ->
                    if (targetPad != null && targetPad in 0..7) {
                        soundImportManager.assignToPad(
                            patchNumber = patchManager.activePatchNumber.value,
                            padIndex = targetPad,
                            sound = snd
                        )
                        val msg = "Assigned '${snd.displayName}' to Pad ${targetPad + 1}"
                        padImportFeedback = PadImportFeedback(
                            eventId = System.currentTimeMillis(),
                            padIndex = targetPad,
                            importedSound = snd,
                            isError = false,
                            message = msg
                        )
                        Toast.makeText(this@MainActivity, msg, Toast.LENGTH_SHORT).show()
                    } else {
                        val msg = "Imported sample: ${snd.displayName}"
                        padImportFeedback = PadImportFeedback(
                            eventId = System.currentTimeMillis(),
                            padIndex = null,
                            importedSound = snd,
                            isError = false,
                            message = msg
                        )
                        Toast.makeText(this@MainActivity, msg, Toast.LENGTH_SHORT).show()
                    }
                }.onFailure { err ->
                    val msg = err.message ?: "Failed to import audio sample."
                    padImportFeedback = PadImportFeedback(
                        eventId = System.currentTimeMillis(),
                        padIndex = targetPad,
                        importedSound = null,
                        isError = true,
                        message = msg
                    )
                    Toast.makeText(this@MainActivity, msg, Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private val multiWavPicker = registerForActivityResult(
        OpenMultipleAudioDocumentsContract(
            arrayOf("audio/wav", "audio/x-wav", "audio/wave", "audio/vnd.wave", "audio/*")
        )
    ) { uris ->
        handleMultiAudioSelected(uris, expectedFilter = "wav", label = "WAV")
    }

    private val multiMp3Picker = registerForActivityResult(
        OpenMultipleAudioDocumentsContract(
            arrayOf("audio/mpeg", "audio/mp3", "audio/*")
        )
    ) { uris ->
        handleMultiAudioSelected(uris, expectedFilter = "mp3", label = "MP3")
    }

    private val zipPackPicker = registerForActivityResult(
        OpenSingleDocumentWithMimesContract(
            primaryType = "*/*",
            extraMimeTypes = arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream")
        )
    ) { uri ->
        if (uri != null) {
            phonePatchLoadUiState = phonePatchLoadUiState.copy(
                isBusy = true,
                busyMessage = "Safely extracting & validating ZIP patch pack...",
                errorMessage = null,
                lastCommitResult = null
            )
            lifecycleScope.launch {
                val res = withContext(Dispatchers.IO) { phonePatchImporter.inspectZipPackUri(uri) }
                res.onSuccess { preview ->
                    phonePatchLoadUiState = phonePatchLoadUiState.copy(
                        isBusy = false,
                        busyMessage = "",
                        stagedPreview = preview,
                        errorMessage = null
                    )
                }.onFailure { err ->
                    phonePatchLoadUiState = phonePatchLoadUiState.copy(
                        isBusy = false,
                        busyMessage = "",
                        errorMessage = err.message ?: "Failed to open ZIP patch pack."
                    )
                }
            }
        }
    }

    private val jsonPatchPicker = registerForActivityResult(
        OpenSingleDocumentWithMimesContract(
            primaryType = "*/*",
            extraMimeTypes = arrayOf("application/json", "text/json", "text/plain")
        )
    ) { uri ->
        if (uri != null) {
            phonePatchLoadUiState = phonePatchLoadUiState.copy(
                isBusy = true,
                busyMessage = "Parsing JSON patch configuration...",
                errorMessage = null,
                lastCommitResult = null
            )
            lifecycleScope.launch {
                val res = withContext(Dispatchers.IO) { phonePatchImporter.inspectJsonPatchUri(uri) }
                res.onSuccess { preview ->
                    phonePatchLoadUiState = phonePatchLoadUiState.copy(
                        isBusy = false,
                        busyMessage = "",
                        stagedPreview = preview,
                        errorMessage = null
                    )
                }.onFailure { err ->
                    phonePatchLoadUiState = phonePatchLoadUiState.copy(
                        isBusy = false,
                        busyMessage = "",
                        errorMessage = err.message ?: "Failed to parse JSON patch file."
                    )
                }
            }
        }
    }

    private val missingSampleAudioPicker = registerForActivityResult(OpenAudioDocumentContract()) { uri ->
        val missingFile = pendingMissingFilename
        pendingMissingFilename = null
        val curPreview = phonePatchLoadUiState.stagedPreview
        if (uri != null && missingFile != null && curPreview != null) {
            phonePatchLoadUiState = phonePatchLoadUiState.copy(
                isBusy = true,
                busyMessage = "Decoding replacement for $missingFile...",
                errorMessage = null
            )
            lifecycleScope.launch {
                val res = withContext(Dispatchers.IO) { soundImportManager.importFromUri(uri) }
                res.onSuccess { snd ->
                    val updatedPreview = phonePatchImporter.resolveMissingWithImportedSound(
                        preview = curPreview,
                        missingFilename = missingFile,
                        sound = snd
                    )
                    phonePatchLoadUiState = phonePatchLoadUiState.copy(
                        isBusy = false,
                        busyMessage = "",
                        stagedPreview = updatedPreview,
                        errorMessage = null
                    )
                    Toast.makeText(this@MainActivity, "Resolved '$missingFile' with '${snd.displayName}'", Toast.LENGTH_SHORT).show()
                }.onFailure { err ->
                    phonePatchLoadUiState = phonePatchLoadUiState.copy(
                        isBusy = false,
                        busyMessage = "",
                        errorMessage = err.message ?: "Failed to load replacement sample."
                    )
                }
            }
        }
    }

    private val bluetoothPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { _ ->
        midiManager.refreshDevices()
        midiManager.connectPairedBluetoothMidiDevices()
    }

    private fun handleMultiAudioSelected(uris: List<Uri>, expectedFilter: String, label: String) {
        if (uris.isEmpty()) return
        phonePatchLoadUiState = phonePatchLoadUiState.copy(
            isBusy = true,
            busyMessage = "Importing ${uris.size} $label sample(s) to private storage...",
            errorMessage = null
        )
        lifecycleScope.launch {
            val report = withContext(Dispatchers.IO) {
                phonePatchImporter.importMultipleAudioUris(uris, expectedExtensionFilter = expectedFilter)
            }
            val errSummary = if (report.imported.isEmpty() && report.skippedReasons.isNotEmpty()) {
                report.skippedReasons.joinToString("\n")
            } else if (report.skippedReasons.isNotEmpty()) {
                "Imported ${report.imported.size} · Skipped ${report.skippedReasons.size}: ${report.skippedReasons.first()}"
            } else null

            phonePatchLoadUiState = phonePatchLoadUiState.copy(
                isBusy = false,
                busyMessage = "",
                lastMultiAudioReport = report,
                errorMessage = errSummary
            )
            if (report.imported.isNotEmpty()) {
                Toast.makeText(
                    this@MainActivity,
                    "Imported ${report.imported.size} $label file(s) permanently",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        enableImmersiveFullscreen()

        storageManager = StorageManager(applicationContext)
        effectsProcessor = EffectsProcessor(storageManager)
        equalizerManager = EqualizerManager(storageManager)
        audioEngine = AudioEngine(applicationContext, storageManager, effectsProcessor, equalizerManager)
        patchManager = PatchManager(storageManager)

        midiManager = MidiManager(
            context = applicationContext,
            storageManager = storageManager,
            resolvePadIndexByNote = { incomingNote ->
                patchManager.activePatch.pads.indexOfFirst { it.midiNote == incomingNote }
            }
        ) { padIndex, velocity ->
            val pad = patchManager.activePatch.pads.getOrNull(padIndex) ?: return@MidiManager
            externalPadPulseTimes[padIndex] = System.currentTimeMillis()
            audioEngine.triggerPad(
                sampleKey = pad.sampleKey,
                customSoundId = pad.customSoundId,
                padVolume = pad.volume,
                padPitch = pad.pitch,
                velocity = velocity
            )
            recordingManager.recordHit(pad, velocity)
        }

        recordingManager = RecordingManager(storageManager, patchManager) { padIdx, velocity, sampleKey, customId, midiNote ->
            val pad = patchManager.activePatch.pads.getOrNull(padIdx)
            externalPadPulseTimes[padIdx] = System.currentTimeMillis()
            audioEngine.triggerPad(
                sampleKey = sampleKey,
                customSoundId = customId,
                padVolume = pad?.volume ?: 0.9f,
                padPitch = pad?.pitch ?: 1.0f,
                velocity = velocity
            )
            midiManager.sendPadNoteOn(padIdx, velocity, midiNote)
        }

        soundImportManager = SoundImportManager(applicationContext, storageManager, audioEngine, patchManager)
        phonePatchImporter = PhonePatchImporter(
            context = applicationContext,
            storageManager = storageManager,
            audioEngine = audioEngine,
            patchManager = patchManager,
            soundImportManager = soundImportManager
        )
        kitManager = KitManager(storageManager, patchManager)

        audioEngine.initialize()
        midiManager.initialize()

        setContent {
            OctapadScreen(
                patchManager = patchManager,
                audioEngine = audioEngine,
                effectsProcessor = effectsProcessor,
                equalizerManager = equalizerManager,
                midiManager = midiManager,
                recordingManager = recordingManager,
                soundImportManager = soundImportManager,
                phonePatchImporter = phonePatchImporter,
                kitManager = kitManager,
                phonePatchLoadUiState = phonePatchLoadUiState,
                onUpdatePhonePatchLoadUiState = { transform ->
                    phonePatchLoadUiState = transform(phonePatchLoadUiState)
                },
                onLaunchAudioFilePicker = { targetPadIndex ->
                    pendingImportPadIndex = targetPadIndex
                    audioFilePicker.launch(Unit)
                },
                onLaunchMultiWavPicker = { multiWavPicker.launch(Unit) },
                onLaunchMultiMp3Picker = { multiMp3Picker.launch(Unit) },
                onLaunchZipPackPicker = { zipPackPicker.launch(Unit) },
                onLaunchJsonPatchPicker = { jsonPatchPicker.launch(Unit) },
                onLaunchMissingSamplePicker = { missingFile ->
                    pendingMissingFilename = missingFile
                    missingSampleAudioPicker.launch(Unit)
                },
                padImportFeedback = padImportFeedback,
                onClearImportFeedback = { padImportFeedback = null },
                onRequestBluetoothPermission = {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        bluetoothPermissionLauncher.launch(
                            arrayOf(
                                Manifest.permission.BLUETOOTH_CONNECT,
                                Manifest.permission.BLUETOOTH_SCAN
                            )
                        )
                    }
                },
                externalPulseTimes = externalPadPulseTimes
            )
        }
    }

    override fun onResume() {
        super.onResume()
        enableImmersiveFullscreen()
        audioEngine.onResume()
    }

    override fun onPause() {
        super.onPause()
        audioEngine.onPause()
        effectsProcessor.saveSettings()
        equalizerManager.saveEq()
    }

    override fun onDestroy() {
        super.onDestroy()
        recordingManager.release()
        midiManager.release()
        audioEngine.release()
    }

    private fun enableImmersiveFullscreen() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller.hide(WindowInsetsCompat.Type.systemBars())
    }
}
