package com.mrkayluu.mroctapad

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

/**
 * Electronic drum pad with two strict visual states:
 * 1. Normal Play Mode (isEditMode = false): Clean dark charcoal rubber pad with
 *    blue glowing border, zero text, zero EDIT labels, and independent per-pad
 *    blue flash animation driven by multi-pointer MotionEvent tracking on the pad grid.
 * 2. Pad Edit Mode (isEditMode = true): Highlighted bright blue editable border,
 *    visible EDIT badge/icon + pad assignment label, opening the Individual Pad Editor
 *    on tap WITHOUT playing drum sounds.
 */
@Composable
fun DrumPad(
    padIndex: Int,
    isFingerHeld: Boolean,
    pulseTimestamp: Long,
    isEditMode: Boolean,
    currentSampleName: String,
    isCustomSample: Boolean,
    onEditPadClick: (padIndex: Int) -> Unit,
    modifier: Modifier = Modifier
) {
    var pulseActive by remember { mutableStateOf(false) }

    LaunchedEffect(pulseTimestamp) {
        if (pulseTimestamp > 0L) {
            pulseActive = true
            delay(95L)
            pulseActive = false
        }
    }

    LaunchedEffect(isEditMode) {
        if (isEditMode) {
            pulseActive = false
        }
    }

    val active = !isEditMode && (isFingerHeld || pulseActive)
    val glowAlpha by animateFloatAsState(
        targetValue = when {
            isEditMode -> 0.95f
            active -> 1.0f
            else -> 0.42f
        },
        animationSpec = tween(durationMillis = if (active) 25 else 140),
        label = "padGlow_$padIndex"
    )
    val surfaceFlash by animateFloatAsState(
        targetValue = if (active) 0.34f else 0f,
        animationSpec = tween(durationMillis = if (active) 20 else 150),
        label = "padFlash_$padIndex"
    )

    val cornerShape = RoundedCornerShape(14.dp)

    Box(
        modifier = modifier
            .shadow(
                elevation = if (active) 4.dp else 10.dp,
                shape = cornerShape,
                ambientColor = Color(0xFF0A4DA6),
                spotColor = Color(0xFF1A8CFF)
            )
            .clip(cornerShape)
            .drawBehind {
                drawRoundRect(
                    color = (if (isEditMode) Color(0xFF38BDF8) else Color(0xFF1A90FF)).copy(alpha = glowAlpha * 0.65f),
                    cornerRadius = CornerRadius(14.dp.toPx(), 14.dp.toPx()),
                    style = Stroke(width = if (active || isEditMode) 5.dp.toPx() else 2.5.dp.toPx())
                )
            }
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF1B1E26),
                        Color(0xFF101319),
                        Color(0xFF090B0F)
                    )
                )
            )
            .border(
                width = if (active || isEditMode) 3.dp else 2.dp,
                brush = Brush.linearGradient(
                    colors = listOf(
                        Color(0xFF67E8F9).copy(alpha = glowAlpha),
                        Color(0xFF0E74FF).copy(alpha = glowAlpha),
                        Color(0xFF38BDF8).copy(alpha = glowAlpha)
                    )
                ),
                shape = cornerShape
            )
            .then(
                if (isEditMode) {
                    Modifier.clickable { onEditPadClick(padIndex) }
                } else {
                    Modifier
                }
            )
    ) {
        // Textured rubber inner recess & independent blue illumination
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .fillMaxSize()
                .padding(5.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            Color(0xFF232732),
                            Color(0xFF13161D),
                            Color(0xFF0B0D12)
                        ),
                        center = Offset.Unspecified
                    )
                )
                .drawBehind {
                    if (surfaceFlash > 0.01f) {
                        drawRoundRect(
                            brush = Brush.radialGradient(
                                colors = listOf(
                                    Color(0xFF38BDF8).copy(alpha = surfaceFlash),
                                    Color(0xFF0284C7).copy(alpha = surfaceFlash * 0.45f),
                                    Color.Transparent
                                )
                            ),
                            cornerRadius = CornerRadius(10.dp.toPx(), 10.dp.toPx())
                        )
                    }
                }
        ) {
            if (isEditMode) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color(0xFF0A2E5E).copy(alpha = 0.42f))
                        .padding(10.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(5.dp),
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(Color(0xFF1D8BFF))
                            .border(1.dp, Color(0xFF93C5FD), RoundedCornerShape(6.dp))
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = "Edit Pad ${padIndex + 1}",
                            tint = Color.White,
                            modifier = Modifier.size(13.dp)
                        )
                        Text(
                            text = "EDIT",
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 0.8.sp
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "PAD ${padIndex + 1}",
                        color = Color(0xFFBAE6FD),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.8.sp
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = currentSampleName,
                        color = if (isCustomSample) Color(0xFF6EE7B7) else Color(0xFFE2E8F0),
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.SemiBold,
                        textAlign = TextAlign.Center,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}
