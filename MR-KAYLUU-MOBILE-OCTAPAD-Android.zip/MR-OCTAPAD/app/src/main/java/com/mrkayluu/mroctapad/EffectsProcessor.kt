package com.mrkayluu.mroctapad

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tanh

class EffectsProcessor(private val storageManager: StorageManager) {

    private val _settings = MutableStateFlow(storageManager.loadEffects())
    val settings: StateFlow<EffectsSettings> = _settings.asStateFlow()

    // Delay & Echo buffers (supports up to 96kHz)
    private val maxDelaySamples = 96000
    private val delayBuffer = FloatArray(maxDelaySamples)
    private var delayWriteIdx = 0

    private val echoBuffer = FloatArray(maxDelaySamples)
    private var echoWriteIdx = 0
    private var echoLpState = 0f

    // Schroeder Reverb comb & all-pass delay lines
    private val combLengths = intArrayOf(1557, 1617, 1491, 1422)
    private val combBuffers = Array(4) { FloatArray(combLengths[it] * 2) }
    private val combIndices = IntArray(4)
    private val combFilterStore = FloatArray(4)

    private val allPassLengths = intArrayOf(225, 556)
    private val allPassBuffers = Array(2) { FloatArray(allPassLengths[it] * 2) }
    private val allPassIndices = IntArray(2)

    // Master Bass (Low Shelf) & Treble (High Shelf) biquad states
    private var lowB0 = 1f; private var lowB1 = 0f; private var lowB2 = 0f
    private var lowA1 = 0f; private var lowA2 = 0f
    private var lowX1 = 0f; private var lowX2 = 0f; private var lowY1 = 0f; private var lowY2 = 0f

    private var highB0 = 1f; private var highB1 = 0f; private var highB2 = 0f
    private var highA1 = 0f; private var highA2 = 0f
    private var highX1 = 0f; private var highX2 = 0f; private var highY1 = 0f; private var highY2 = 0f

    @Volatile
    private var lastSampleRate = 44100

    @Volatile
    private var coeffsDirty = true

    fun updateSettings(transform: (EffectsSettings) -> EffectsSettings) {
        val next = transform(_settings.value)
        _settings.value = EffectsSettings(
            masterVolume = next.masterVolume.coerceIn(0f, 1.5f),
            bassDb = next.bassDb.coerceIn(-12f, 12f),
            trebleDb = next.trebleDb.coerceIn(-12f, 12f),
            pitchMultiplier = next.pitchMultiplier.coerceIn(0.5f, 2.0f),
            echoMix = next.echoMix.coerceIn(0f, 1f),
            delayMix = next.delayMix.coerceIn(0f, 1f),
            reverbMix = next.reverbMix.coerceIn(0f, 1f)
        )
        coeffsDirty = true
    }

    fun saveSettings() {
        storageManager.saveEffects(_settings.value)
    }

    fun restoreSettings() {
        _settings.value = storageManager.loadEffects()
        coeffsDirty = true
    }

    fun resetEffects() {
        _settings.value = EffectsSettings()
        coeffsDirty = true
        saveSettings()
    }

    fun processMonoBuffer(buffer: FloatArray, frameCount: Int, sampleRate: Int) {
        val fx = _settings.value
        if (coeffsDirty || sampleRate != lastSampleRate) {
            lastSampleRate = sampleRate
            recalculateShelfFilters(fx.bassDb, fx.trebleDb, sampleRate)
            coeffsDirty = false
        }

        val delaySamples = (sampleRate * 0.28f).toInt().coerceIn(64, maxDelaySamples - 1)
        val echoSamples = (sampleRate * 0.43f).toInt().coerceIn(64, maxDelaySamples - 1)
        val srScale = sampleRate / 44100f

        for (i in 0 until frameCount) {
            var dry = buffer[i]

            // 1. Master Bass Low-Shelf Biquad
            if (fx.bassDb != 0f) {
                val y = lowB0 * dry + lowB1 * lowX1 + lowB2 * lowX2 - lowA1 * lowY1 - lowA2 * lowY2
                lowX2 = lowX1; lowX1 = dry
                lowY2 = lowY1; lowY1 = y
                dry = y
            }

            // 2. Master Treble High-Shelf Biquad
            if (fx.trebleDb != 0f) {
                val y = highB0 * dry + highB1 * highX1 + highB2 * highX2 - highA1 * highY1 - highA2 * highY2
                highX2 = highX1; highX1 = dry
                highY2 = highY1; highY1 = y
                dry = y
            }

            var wetSum = 0f

            // 3. Clean rhythmic Delay
            val delayReadIdx = (delayWriteIdx - delaySamples + maxDelaySamples) % maxDelaySamples
            val delayed = delayBuffer[delayReadIdx]
            delayBuffer[delayWriteIdx] = dry + delayed * (0.28f * fx.delayMix)
            delayWriteIdx = (delayWriteIdx + 1) % maxDelaySamples
            if (fx.delayMix > 0.001f) {
                wetSum += delayed * fx.delayMix * 0.65f
            }

            // 4. Warm Analog Echo (low-pass damped feedback)
            val echoReadIdx = (echoWriteIdx - echoSamples + maxDelaySamples) % maxDelaySamples
            val rawEcho = echoBuffer[echoReadIdx]
            echoLpState += 0.35f * (rawEcho - echoLpState)
            echoBuffer[echoWriteIdx] = dry + echoLpState * (0.48f * fx.echoMix)
            echoWriteIdx = (echoWriteIdx + 1) % maxDelaySamples
            if (fx.echoMix > 0.001f) {
                wetSum += echoLpState * fx.echoMix * 0.72f
            }

            // 5. Schroeder Reverb
            if (fx.reverbMix > 0.001f) {
                var revOut = 0f
                val feedback = 0.76f + 0.14f * fx.reverbMix
                val damp = 0.25f
                for (c in 0 until 4) {
                    val len = (combLengths[c] * srScale).toInt().coerceIn(64, combBuffers[c].size - 1)
                    val idx = combIndices[c] % len
                    val out = combBuffers[c][idx]
                    combFilterStore[c] = out * (1f - damp) + combFilterStore[c] * damp
                    combBuffers[c][idx] = dry + combFilterStore[c] * feedback
                    combIndices[c] = (idx + 1) % len
                    revOut += out
                }
                revOut *= 0.25f

                for (a in 0 until 2) {
                    val len = (allPassLengths[a] * srScale).toInt().coerceIn(32, allPassBuffers[a].size - 1)
                    val idx = allPassIndices[a] % len
                    val bufOut = allPassBuffers[a][idx]
                    val newIn = revOut + bufOut * 0.5f
                    allPassBuffers[a][idx] = newIn
                    revOut = bufOut - revOut * 0.5f
                    allPassIndices[a] = (idx + 1) % len
                }
                wetSum += revOut * fx.reverbMix * 0.58f
            }

            // 6. Master Volume + Soft-Clip Limiter (anti-clipping)
            val out = (dry + wetSum) * fx.masterVolume
            buffer[i] = tanh(out * 0.92f)
        }
    }

    private fun recalculateShelfFilters(bassDb: Float, trebleDb: Float, sampleRate: Int) {
        // Low-shelf around 130 Hz
        run {
            val a = 10.0.pow(bassDb / 40.0)
            val w0 = 2.0 * PI * 130.0 / sampleRate
            val cosW0 = cos(w0)
            val sinW0 = sin(w0)
            val alpha = sinW0 / 2.0 * sqrt((a + 1.0 / a) * (1.0 / 0.8 - 1.0) + 2.0)
            val twoSqrtAAlpha = 2.0 * sqrt(a) * alpha
            val a0 = (a + 1.0) + (a - 1.0) * cosW0 + twoSqrtAAlpha
            lowB0 = ((a * ((a + 1.0) - (a - 1.0) * cosW0 + twoSqrtAAlpha)) / a0).toFloat()
            lowB1 = ((2.0 * a * ((a - 1.0) - (a + 1.0) * cosW0)) / a0).toFloat()
            lowB2 = ((a * ((a + 1.0) - (a - 1.0) * cosW0 - twoSqrtAAlpha)) / a0).toFloat()
            lowA1 = ((-2.0 * ((a - 1.0) + (a + 1.0) * cosW0)) / a0).toFloat()
            lowA2 = (((a + 1.0) + (a - 1.0) * cosW0 - twoSqrtAAlpha) / a0).toFloat()
        }

        // High-shelf around 5200 Hz
        run {
            val a = 10.0.pow(trebleDb / 40.0)
            val w0 = 2.0 * PI * 5200.0 / sampleRate
            val cosW0 = cos(w0)
            val sinW0 = sin(w0)
            val alpha = sinW0 / 2.0 * sqrt((a + 1.0 / a) * (1.0 / 0.8 - 1.0) + 2.0)
            val twoSqrtAAlpha = 2.0 * sqrt(a) * alpha
            val a0 = (a + 1.0) - (a - 1.0) * cosW0 + twoSqrtAAlpha
            highB0 = ((a * ((a + 1.0) + (a - 1.0) * cosW0 + twoSqrtAAlpha)) / a0).toFloat()
            highB1 = ((-2.0 * a * ((a - 1.0) + (a + 1.0) * cosW0)) / a0).toFloat()
            highB2 = ((a * ((a + 1.0) + (a - 1.0) * cosW0 - twoSqrtAAlpha)) / a0).toFloat()
            highA1 = ((2.0 * ((a - 1.0) - (a + 1.0) * cosW0)) / a0).toFloat()
            highA2 = (((a + 1.0) - (a - 1.0) * cosW0 - twoSqrtAAlpha) / a0).toFloat()
        }
    }
}
