package com.mrkayluu.mroctapad

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.pm.PackageManager
import android.media.midi.MidiDevice
import android.media.midi.MidiDeviceInfo
import android.media.midi.MidiInputPort
import android.media.midi.MidiManager as AndroidMidiManager
import android.media.midi.MidiOutputPort
import android.media.midi.MidiReceiver
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.core.content.ContextCompat
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class MidiDeviceSummary(
    val id: Int,
    val name: String,
    val manufacturer: String,
    val typeLabel: String,
    val hasInputPort: Boolean,
    val hasOutputPort: Boolean,
    val isConnected: Boolean
)

data class MidiStatusState(
    val isMidiSupported: Boolean,
    val bluetoothSupported: Boolean,
    val bluetoothPermissionGranted: Boolean,
    val statusMessage: String,
    val connectedInputName: String?,
    val connectedOutputName: String?,
    val availableDevices: List<MidiDeviceSummary>,
    val lastIncomingNote: String? = null
)

class MidiManager(
    private val context: Context,
    private val storageManager: StorageManager,
    private val resolvePadIndexByNote: ((note: Int) -> Int)? = null,
    private val onExternalPadTrigger: (padIndex: Int, velocity: Float) -> Unit
) {
    private val androidMidi: AndroidMidiManager? =
        context.getSystemService(Context.MIDI_SERVICE) as? AndroidMidiManager

    private val mainHandler = Handler(Looper.getMainLooper())

    private val _settings = MutableStateFlow(storageManager.loadMidi())
    val settings: StateFlow<MidiSettings> = _settings.asStateFlow()

    private val _status = MutableStateFlow(
        MidiStatusState(
            isMidiSupported = isMidiFeatureAvailable(),
            bluetoothSupported = isBluetoothAvailable(),
            bluetoothPermissionGranted = hasBluetoothPermission(),
            statusMessage = if (isMidiFeatureAvailable()) "No MIDI device connected" else "MIDI unsupported on this device",
            connectedInputName = null,
            connectedOutputName = null,
            availableDevices = emptyList()
        )
    )
    val status: StateFlow<MidiStatusState> = _status.asStateFlow()

    private var openDevice: MidiDevice? = null
    private var openDeviceId: Int = -1
    private var inputPort: MidiInputPort? = null   // App -> External Synth
    private var outputPort: MidiOutputPort? = null // External Controller -> App

    private val incomingReceiver = object : MidiReceiver() {
        override fun onSend(msg: ByteArray, offset: Int, count: Int, timestamp: Long) {
            if (!_settings.value.midiInEnabled) return
            var idx = offset
            val end = offset + count
            while (idx < end) {
                val statusByte = msg[idx].toInt() and 0xFF
                val command = statusByte and 0xF0
                val channel = (statusByte and 0x0F) + 1

                if (command == 0x90 && idx + 2 < end) {
                    val note = msg[idx + 1].toInt() and 0x7F
                    val rawVel = msg[idx + 2].toInt() and 0x7F
                    if (rawVel > 0 && channel == _settings.value.channel) {
                        val velNorm = ((rawVel / 127f) * _settings.value.velocityScale).coerceIn(0.05f, 1.0f)
                        val patchMatch = resolvePadIndexByNote?.invoke(note) ?: -1
                        val padIdx = if (patchMatch in 0..7) patchMatch else _settings.value.padNotes.indexOf(note)
                        _status.value = _status.value.copy(
                            lastIncomingNote = "Ch $channel · Note $note (Vel $rawVel)"
                        )
                        if (padIdx in 0..7) {
                            onExternalPadTrigger(padIdx, velNorm)
                        }
                    }
                    idx += 3
                } else if (command == 0x80 && idx + 2 < end) {
                    idx += 3
                } else {
                    idx += 1
                }
            }
        }
    }

    private val deviceCallback = object : AndroidMidiManager.DeviceCallback() {
        override fun onDeviceAdded(device: MidiDeviceInfo) {
            refreshDevices()
            if (openDevice == null) {
                connectDevice(device.id)
            }
        }

        override fun onDeviceRemoved(device: MidiDeviceInfo) {
            if (device.id == openDeviceId) {
                disconnect()
                _status.value = _status.value.copy(
                    statusMessage = "MIDI device disconnected"
                )
            }
            refreshDevices()
        }
    }

    fun initialize() {
        val midi = androidMidi ?: return
        if (!isMidiFeatureAvailable()) return

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            midi.registerDeviceCallback(
                AndroidMidiManager.TRANSPORT_MIDI_BYTE_STREAM,
                { it.run() },
                deviceCallback
            )
        } else {
            @Suppress("DEPRECATION")
            midi.registerDeviceCallback(deviceCallback, mainHandler)
        }
        refreshDevices()
    }

    fun refreshDevices() {
        val midi = androidMidi
        if (midi == null || !isMidiFeatureAvailable()) {
            _status.value = MidiStatusState(
                isMidiSupported = false,
                bluetoothSupported = isBluetoothAvailable(),
                bluetoothPermissionGranted = hasBluetoothPermission(),
                statusMessage = "Android MIDI API is not supported on this hardware",
                connectedInputName = null,
                connectedOutputName = null,
                availableDevices = emptyList()
            )
            return
        }

        val rawList: Collection<MidiDeviceInfo> =
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                midi.getDevicesForTransport(AndroidMidiManager.TRANSPORT_MIDI_BYTE_STREAM)
            } else {
                @Suppress("DEPRECATION")
                midi.devices.toList()
            }

        val summaries = rawList.map { info ->
            val props = info.properties
            val name = props.getString(MidiDeviceInfo.PROPERTY_NAME)
                ?: props.getString(MidiDeviceInfo.PROPERTY_PRODUCT)
                ?: "MIDI Device #${info.id}"
            val mfg = props.getString(MidiDeviceInfo.PROPERTY_MANUFACTURER) ?: "Generic"
            val typeLabel = when (info.type) {
                MidiDeviceInfo.TYPE_USB -> "USB MIDI"
                MidiDeviceInfo.TYPE_BLUETOOTH -> "Bluetooth MIDI"
                MidiDeviceInfo.TYPE_VIRTUAL -> "Virtual MIDI"
                else -> "MIDI"
            }
            MidiDeviceSummary(
                id = info.id,
                name = name,
                manufacturer = mfg,
                typeLabel = typeLabel,
                hasInputPort = info.inputPortCount > 0,
                hasOutputPort = info.outputPortCount > 0,
                isConnected = info.id == openDeviceId && openDevice != null
            )
        }

        _status.value = _status.value.copy(
            isMidiSupported = true,
            bluetoothSupported = isBluetoothAvailable(),
            bluetoothPermissionGranted = hasBluetoothPermission(),
            availableDevices = summaries
        )
    }

    fun connectDevice(deviceId: Int) {
        val midi = androidMidi ?: return
        val infoList = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            midi.getDevicesForTransport(AndroidMidiManager.TRANSPORT_MIDI_BYTE_STREAM)
        } else {
            @Suppress("DEPRECATION")
            midi.devices.toList()
        }
        val target = infoList.firstOrNull { it.id == deviceId } ?: run {
            _status.value = _status.value.copy(statusMessage = "Selected MIDI device no longer available")
            return
        }

        disconnect()
        _status.value = _status.value.copy(statusMessage = "Connecting to MIDI device...")

        midi.openDevice(target, { device ->
            if (device == null) {
                _status.value = _status.value.copy(statusMessage = "Failed to open MIDI device")
                return@openDevice
            }
            openDevice = device
            openDeviceId = target.id

            val props = target.properties
            val devName = props.getString(MidiDeviceInfo.PROPERTY_NAME)
                ?: props.getString(MidiDeviceInfo.PROPERTY_PRODUCT)
                ?: "MIDI #${target.id}"

            if (target.inputPortCount > 0) {
                inputPort = device.openInputPort(0)
            }
            if (target.outputPortCount > 0) {
                outputPort = device.openOutputPort(0)?.also { port ->
                    port.connect(incomingReceiver)
                }
            }

            _status.value = _status.value.copy(
                statusMessage = "Connected: $devName",
                connectedInputName = if (outputPort != null) devName else null,
                connectedOutputName = if (inputPort != null) devName else null
            )
            refreshDevices()
        }, mainHandler)
    }

    @SuppressLint("MissingPermission")
    fun connectPairedBluetoothMidiDevices() {
        val midi = androidMidi ?: return
        if (!isBluetoothAvailable()) {
            _status.value = _status.value.copy(statusMessage = "Bluetooth is unavailable or disabled")
            return
        }
        if (!hasBluetoothPermission()) {
            _status.value = _status.value.copy(statusMessage = "Bluetooth permission required to scan/connect BLE MIDI")
            return
        }
        val btMgr = context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
        val bonded: Set<BluetoothDevice> = btMgr?.adapter?.bondedDevices ?: emptySet()
        if (bonded.isEmpty()) {
            _status.value = _status.value.copy(statusMessage = "No paired Bluetooth MIDI devices found in system settings")
            return
        }
        bonded.forEach { btDevice ->
            midi.openBluetoothDevice(btDevice, { opened ->
                if (opened != null) {
                    openDevice = opened
                    openDeviceId = opened.info.id
                    if (opened.info.inputPortCount > 0) inputPort = opened.openInputPort(0)
                    if (opened.info.outputPortCount > 0) {
                        outputPort = opened.openOutputPort(0)?.also { it.connect(incomingReceiver) }
                    }
                    _status.value = _status.value.copy(
                        statusMessage = "Bluetooth MIDI connected: ${btDevice.name ?: btDevice.address}",
                        connectedInputName = if (outputPort != null) btDevice.name else null,
                        connectedOutputName = if (inputPort != null) btDevice.name else null
                    )
                    refreshDevices()
                }
            }, mainHandler)
        }
    }

    fun disconnect() {
        try { outputPort?.disconnect(incomingReceiver) } catch (_: Exception) {}
        try { outputPort?.close() } catch (_: Exception) {}
        try { inputPort?.close() } catch (_: Exception) {}
        try { openDevice?.close() } catch (_: Exception) {}
        outputPort = null
        inputPort = null
        openDevice = null
        openDeviceId = -1
        _status.value = _status.value.copy(
            statusMessage = "Disconnected",
            connectedInputName = null,
            connectedOutputName = null
        )
        refreshDevices()
    }

    fun sendPadNoteOn(padIndex: Int, velocity: Float = 1.0f, midiNoteOverride: Int? = null) {
        val port = inputPort ?: return
        val cfg = _settings.value
        if (!cfg.midiOutEnabled) return

        val note = (midiNoteOverride ?: cfg.padNotes.getOrElse(padIndex) { 36 + padIndex }).coerceIn(0, 127)
        val ch = (cfg.channel - 1).coerceIn(0, 15)
        val velByte = (velocity * cfg.velocityScale * 127f).toInt().coerceIn(1, 127)

        val packet = byteArrayOf(
            (0x90 or ch).toByte(),
            note.toByte(),
            velByte.toByte()
        )
        try {
            port.send(packet, 0, packet.size)
        } catch (_: Exception) {
        }
    }

    fun sendPadNoteOff(padIndex: Int, midiNoteOverride: Int? = null) {
        val port = inputPort ?: return
        val cfg = _settings.value
        if (!cfg.midiOutEnabled) return

        val note = (midiNoteOverride ?: cfg.padNotes.getOrElse(padIndex) { 36 + padIndex }).coerceIn(0, 127)
        val ch = (cfg.channel - 1).coerceIn(0, 15)
        val packet = byteArrayOf(
            (0x80 or ch).toByte(),
            note.toByte(),
            0
        )
        try {
            port.send(packet, 0, packet.size)
        } catch (_: Exception) {
        }
    }

    fun updateSettings(transform: (MidiSettings) -> MidiSettings) {
        val next = transform(_settings.value)
        _settings.value = MidiSettings(
            channel = next.channel.coerceIn(1, 16),
            velocityScale = next.velocityScale.coerceIn(0.2f, 1.5f),
            midiOutEnabled = next.midiOutEnabled,
            midiInEnabled = next.midiInEnabled,
            padNotes = next.padNotes.map { it.coerceIn(0, 127) }
        )
        storageManager.saveMidi(_settings.value)
    }

    fun release() {
        try {
            @Suppress("DEPRECATION")
            androidMidi?.unregisterDeviceCallback(deviceCallback)
        } catch (_: Exception) {
        }
        disconnect()
    }

    private fun isMidiFeatureAvailable(): Boolean =
        context.packageManager.hasSystemFeature(PackageManager.FEATURE_MIDI) && androidMidi != null

    private fun isBluetoothAvailable(): Boolean {
        val btMgr = context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
        val adapter: BluetoothAdapter? = btMgr?.adapter
        return context.packageManager.hasSystemFeature(PackageManager.FEATURE_BLUETOOTH_LE) &&
            adapter != null && adapter.isEnabled
    }

    private fun hasBluetoothPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT) ==
                PackageManager.PERMISSION_GRANTED
        } else {
            ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH) ==
                PackageManager.PERMISSION_GRANTED
        }
    }
}
