package com.mrkayluu.mroctapad

import android.view.MotionEvent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.pointerInteropFilter
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.min
import kotlin.math.roundToInt

@OptIn(ExperimentalComposeUiApi::class)
@Composable
fun OctapadScreen(
    patchManager: PatchManager,
    audioEngine: AudioEngine,
    effectsProcessor: EffectsProcessor,
    equalizerManager: EqualizerManager,
    midiManager: MidiManager,
    recordingManager: RecordingManager,
    soundImportManager: SoundImportManager,
    phonePatchImporter: PhonePatchImporter,
    kitManager: KitManager,
    phonePatchLoadUiState: PhonePatchLoadUiState,
    onUpdatePhonePatchLoadUiState: ((PhonePatchLoadUiState) -> PhonePatchLoadUiState) -> Unit,
    onLaunchAudioFilePicker: (targetPadIndex: Int?) -> Unit,
    onLaunchMultiWavPicker: () -> Unit,
    onLaunchMultiMp3Picker: () -> Unit,
    onLaunchZipPackPicker: () -> Unit,
    onLaunchJsonPatchPicker: () -> Unit,
    onLaunchMissingSamplePicker: (missingFilename: String) -> Unit,
    padImportFeedback: PadImportFeedback?,
    onClearImportFeedback: () -> Unit,
    onRequestBluetoothPermission: () -> Unit,
    externalPulseTimes: List<Long>
) {
    val patches by patchManager.patches.collectAsState()
    val activePatchNum by patchManager.activePatchNumber.collectAsState()
    val effects by effectsProcessor.settings.collectAsState()
    val eq by equalizerManager.settings.collectAsState()
    val midiSettings by midiManager.settings.collectAsState()
    val midiStatus by midiManager.status.collectAsState()
    val quality by audioEngine.qualitySettings.collectAsState()
    val hwCaps by audioEngine.capabilities.collectAsState()
    val activeVoices by audioEngine.activeVoiceCount.collectAsState()
    val recorderState by recordingManager.state.collectAsState()
    val recordings by recordingManager.recordings.collectAsState()
    val importedSounds by soundImportManager.importedSounds.collectAsState()
    val kits by kitManager.kits.collectAsState()

    var activePanel by remember { mutableStateOf(ActivePanel.NONE) }
    var isEditMode by remember { mutableStateOf(false) }
    var editingPadIndex by remember { mutableIntStateOf(0) }
    val localPadPulse = remember { mutableStateListOf(0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L) }
    val padPressedStates = remember { mutableStateListOf(false, false, false, false, false, false, false, false) }
    val activePointerToPad = remember { HashMap<Int, Int>() }
    val padBounds = remember { Array<Rect?>(8) { null } }
    var gridCoords by remember { mutableStateOf<LayoutCoordinates?>(null) }

    val activePatch = patches.getOrElse(activePatchNum - 1) { patches.first() }

    val handlePadTrigger: (Int, Float) -> Unit = { padIndex, velocity ->
        val pad = activePatch.pads.getOrNull(padIndex)
        if (pad != null) {
            localPadPulse[padIndex] = System.nanoTime()
            audioEngine.triggerPad(
                sampleKey = pad.sampleKey,
                customSoundId = pad.customSoundId,
                padVolume = pad.volume,
                padPitch = pad.pitch,
                velocity = velocity
            )
            midiManager.sendPadNoteOn(padIndex, velocity, pad.midiNote)
            recordingManager.recordHit(pad, velocity)
        }
    }

    val handlePadRelease: (Int) -> Unit = { padIndex ->
        val pad = activePatch.pads.getOrNull(padIndex)
        midiManager.sendPadNoteOff(padIndex, pad?.midiNote)
    }

    val currentIsEditMode by rememberUpdatedState(isEditMode)
    val currentOnPadTrigger by rememberUpdatedState(handlePadTrigger)
    val currentOnPadRelease by rememberUpdatedState(handlePadRelease)

    LaunchedEffect(isEditMode) {
        if (isEditMode) {
            activePointerToPad.clear()
            for (i in 0..7) {
                padPressedStates[i] = false
            }
        }
    }

    fun syncPadPressedStates() {
        for (i in 0..7) {
            padPressedStates[i] = activePointerToPad.containsValue(i)
        }
    }

    fun hitTestPad(x: Float, y: Float): Int {
        val pt = Offset(x, y)
        for (i in 0..7) {
            if (padBounds[i]?.contains(pt) == true) return i
        }
        val size = gridCoords?.size ?: return -1
        if (size.width <= 0 || size.height <= 0) return -1
        if (x < 0f || x > size.width || y < 0f || y > size.height) return -1
        val col = ((x / size.width.toFloat()) * 4f).toInt().coerceIn(0, 3)
        val row = ((y / size.height.toFloat()) * 2f).toInt().coerceIn(0, 1)
        return row * 4 + col
    }

    // Fullscreen dark stage with maximum fit-inside proportional scaling (1360x700)
    BoxWithConstraints(
        contentAlignment = Alignment.Center,
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF070A0F))
    ) {
        val scale = min(maxWidth.value / 1360f, maxHeight.value / 700f).coerceAtLeast(0.1f)

        // Fixed 1360x700 hardware chassis proportionally scaled to fill available screen
        Box(
            modifier = Modifier
                .requiredSize(1360.dp, 700.dp)
                .graphicsLayer {
                    scaleX = scale
                    scaleY = scale
                    transformOrigin = TransformOrigin.Center
                }
                .padding(6.dp)
                .shadow(24.dp, RoundedCornerShape(22.dp))
                .clip(RoundedCornerShape(22.dp))
                .background(
                    Brush.linearGradient(
                        colors = listOf(
                            Color(0xFFF8FAFC),
                            Color(0xFFE2E8F0),
                            Color(0xFFCBD5E1),
                            Color(0xFFE9EEF5)
                        )
                    )
                )
                .border(3.dp, Color(0xFFFFFFFF), RoundedCornerShape(22.dp))
                .padding(14.dp)
        ) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                // LEFT SIDE: 8 Large Dark Rubber Drum Pads (4 columns x 2 rows)
                // Multi-pointer MotionEvent handler tracks all simultaneous fingers independently
                Box(
                    modifier = Modifier
                        .weight(0.715f)
                        .fillMaxHeight()
                        .shadow(10.dp, RoundedCornerShape(16.dp))
                        .clip(RoundedCornerShape(16.dp))
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(Color(0xFF1F2530), Color(0xFF12161E))
                            )
                        )
                        .border(2.dp, Color(0xFF94A3B8), RoundedCornerShape(16.dp))
                        .padding(14.dp)
                ) {
                    Column(
                        verticalArrangement = Arrangement.spacedBy(14.dp),
                        modifier = Modifier
                            .fillMaxSize()
                            .onGloballyPositioned { coords ->
                                gridCoords = coords
                            }
                            .then(
                                if (!currentIsEditMode) {
                                    Modifier.pointerInteropFilter { motionEvent ->
                                        when (motionEvent.actionMasked) {
                                            MotionEvent.ACTION_DOWN -> {
                                                activePointerToPad.clear()
                                                val idx = motionEvent.actionIndex
                                                val pid = motionEvent.getPointerId(idx)
                                                val padIdx = hitTestPad(motionEvent.getX(idx), motionEvent.getY(idx))
                                                if (padIdx in 0..7) {
                                                    activePointerToPad[pid] = padIdx
                                                    syncPadPressedStates()
                                                    val p = motionEvent.getPressure(idx)
                                                    val vel = if (p > 0.05f && p <= 1f) (0.72f + p * 0.28f).coerceIn(0.6f, 1f) else 0.94f
                                                    currentOnPadTrigger(padIdx, vel)
                                                } else {
                                                    syncPadPressedStates()
                                                }
                                                true
                                            }
                                            MotionEvent.ACTION_POINTER_DOWN -> {
                                                val idx = motionEvent.actionIndex
                                                val pid = motionEvent.getPointerId(idx)
                                                val padIdx = hitTestPad(motionEvent.getX(idx), motionEvent.getY(idx))
                                                if (padIdx in 0..7) {
                                                    activePointerToPad[pid] = padIdx
                                                    syncPadPressedStates()
                                                    val p = motionEvent.getPressure(idx)
                                                    val vel = if (p > 0.05f && p <= 1f) (0.72f + p * 0.28f).coerceIn(0.6f, 1f) else 0.94f
                                                    currentOnPadTrigger(padIdx, vel)
                                                }
                                                true
                                            }
                                            MotionEvent.ACTION_POINTER_UP -> {
                                                val idx = motionEvent.actionIndex
                                                val pid = motionEvent.getPointerId(idx)
                                                val releasedPad = activePointerToPad.remove(pid)
                                                syncPadPressedStates()
                                                if (releasedPad != null && !padPressedStates[releasedPad]) {
                                                    currentOnPadRelease(releasedPad)
                                                }
                                                true
                                            }
                                            MotionEvent.ACTION_UP,
                                            MotionEvent.ACTION_CANCEL -> {
                                                val padsToRelease = activePointerToPad.values.toSet()
                                                activePointerToPad.clear()
                                                for (i in 0..7) {
                                                    padPressedStates[i] = false
                                                }
                                                padsToRelease.forEach { currentOnPadRelease(it) }
                                                true
                                            }
                                            MotionEvent.ACTION_MOVE -> true
                                            else -> true
                                        }
                                    }
                                } else {
                                    Modifier
                                }
                            )
                    ) {
                        // Top Row: Pads 1, 2, 3, 4
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1f)
                        ) {
                            for (padIdx in 0..3) {
                                val padCfg = activePatch.pads.getOrNull(padIdx)
                                DrumPad(
                                    padIndex = padIdx,
                                    isFingerHeld = padPressedStates[padIdx],
                                    pulseTimestamp = externalPulseTimes[padIdx] + localPadPulse[padIdx],
                                    isEditMode = isEditMode,
                                    currentSampleName = padCfg?.sampleName ?: "Pad ${padIdx + 1}",
                                    isCustomSample = padCfg?.customSoundId != null,
                                    onEditPadClick = { idx ->
                                        editingPadIndex = idx
                                        onClearImportFeedback()
                                        activePanel = ActivePanel.PAD_EDITOR
                                    },
                                    modifier = Modifier
                                        .weight(1f)
                                        .fillMaxHeight()
                                        .onGloballyPositioned { coords ->
                                            val gc = gridCoords
                                            if (gc != null && gc.isAttached && coords.isAttached) {
                                                padBounds[padIdx] = gc.localBoundingBoxOf(coords, clipBounds = false)
                                            }
                                        }
                                )
                            }
                        }

                        // Bottom Row: Pads 5, 6, 7, 8
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1f)
                        ) {
                            for (padIdx in 4..7) {
                                val padCfg = activePatch.pads.getOrNull(padIdx)
                                DrumPad(
                                    padIndex = padIdx,
                                    isFingerHeld = padPressedStates[padIdx],
                                    pulseTimestamp = externalPulseTimes[padIdx] + localPadPulse[padIdx],
                                    isEditMode = isEditMode,
                                    currentSampleName = padCfg?.sampleName ?: "Pad ${padIdx + 1}",
                                    isCustomSample = padCfg?.customSoundId != null,
                                    onEditPadClick = { idx ->
                                        editingPadIndex = idx
                                        onClearImportFeedback()
                                        activePanel = ActivePanel.PAD_EDITOR
                                    },
                                    modifier = Modifier
                                        .weight(1f)
                                        .fillMaxHeight()
                                        .onGloballyPositioned { coords ->
                                            val gc = gridCoords
                                            if (gc != null && gc.isAttached && coords.isAttached) {
                                                padBounds[padIdx] = gc.localBoundingBoxOf(coords, clipBounds = false)
                                            }
                                        }
                                )
                            }
                        }
                    }
                }

                // RIGHT SIDE: Compact Glossy Black Control Panel (No knobs on main screen)
                ControlPanel(
                    patches = patches,
                    activePatchNumber = activePatchNum,
                    activePanel = activePanel,
                    isEditMode = isEditMode,
                    onToggleEditMode = {
                        val next = !isEditMode
                        isEditMode = next
                        if (!next && (activePanel == ActivePanel.PAD_EDITOR || activePanel == ActivePanel.PATCH_EDITOR)) {
                            activePanel = ActivePanel.NONE
                        }
                    },
                    onOpenPanel = { panel ->
                        activePanel = if (activePanel == panel) ActivePanel.NONE else panel
                    },
                    onSelectPatch = { patchManager.selectPatch(it) },
                    onPreviousPatch = { patchManager.previousPatch() },
                    onNextPatch = { patchManager.nextPatch() },
                    modifier = Modifier.weight(0.285f)
                )
            }
        }

        // Functional Panels Overlay (scales natively to readable screen density)
        if (activePanel != ActivePanel.NONE) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.72f))
                    .clickable(onClick = { activePanel = ActivePanel.NONE })
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(0.88f)
                        .fillMaxHeight(0.88f)
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0xFF0E141E))
                        .border(1.5.dp, Color(0xFF38BDF8), RoundedCornerShape(16.dp))
                        .clickable(enabled = false, onClick = {})
                        .padding(16.dp)
                ) {
                    when (activePanel) {
                        ActivePanel.PATCH_LOAD -> PatchLoadPanel(
                            patches = patches,
                            activePatchNumber = activePatchNum,
                            activePatch = activePatch,
                            categories = patchManager.categories,
                            bundledLibrary = patchManager.bundledLibrary,
                            importedSounds = importedSounds,
                            phonePatchLoadUiState = phonePatchLoadUiState,
                            isFactoryCustomized = { num -> patchManager.isFactorySlotCustomized(num) },
                            onSelectPatch = { patchManager.selectPatch(it) },
                            onPreviousPatch = { patchManager.previousPatch() },
                            onNextPatch = { patchManager.nextPatch() },
                            onDeleteImportedPatch = { num -> patchManager.deleteImportedPatch(num) },
                            onRestoreOriginalPatch = { num -> patchManager.resetPatchToDefault(num) },
                            onLaunchMultiWavPicker = onLaunchMultiWavPicker,
                            onLaunchMultiMp3Picker = onLaunchMultiMp3Picker,
                            onLaunchZipPackPicker = onLaunchZipPackPicker,
                            onLaunchJsonPatchPicker = onLaunchJsonPatchPicker,
                            onLaunchMissingSamplePicker = onLaunchMissingSamplePicker,
                            onPreviewSound = { key, customId, vol, pitch ->
                                audioEngine.triggerPad(key, customId, vol, pitch, 1.0f)
                            },
                            onAssignSoundToPad = { padIdx, snd ->
                                soundImportManager.assignToPad(activePatchNum, padIdx, snd)
                            },
                            onSaveActivePadsAsImportedPatch = { patchName ->
                                patchManager.importPatchesCollection(
                                    incoming = listOf(
                                        PatchSlot(
                                            number = 501,
                                            name = patchName,
                                            category = "Imported Phone",
                                            pads = activePatch.pads,
                                            isImported = true,
                                            sourcePackName = "Custom Sample Mix"
                                        )
                                    ),
                                    selectFirstImported = true
                                )
                            },
                            onResolveMissingWithSound = { filename, snd ->
                                val cur = phonePatchLoadUiState.stagedPreview ?: return@PatchLoadPanel
                                val next = phonePatchImporter.resolveMissingWithImportedSound(cur, filename, snd)
                                onUpdatePhonePatchLoadUiState { it.copy(stagedPreview = next) }
                            },
                            onResolveMissingWithBundled = { filename, b ->
                                val cur = phonePatchLoadUiState.stagedPreview ?: return@PatchLoadPanel
                                val next = phonePatchImporter.resolveMissingWithBundledSample(cur, filename, b)
                                onUpdatePhonePatchLoadUiState { it.copy(stagedPreview = next) }
                            },
                            onCommitStagedPreview = { singleLocalId ->
                                val cur = phonePatchLoadUiState.stagedPreview ?: return@PatchLoadPanel
                                val result = phonePatchImporter.commitStagedPreview(cur, singleLocalId)
                                onUpdatePhonePatchLoadUiState {
                                    it.copy(
                                        stagedPreview = if (singleLocalId == null) null else it.stagedPreview,
                                        lastCommitResult = result,
                                        errorMessage = null
                                    )
                                }
                            },
                            onCancelStagedPreview = {
                                phonePatchLoadUiState.stagedPreview?.let { phonePatchImporter.cancelStagedPreview(it) }
                                onUpdatePhonePatchLoadUiState { it.copy(stagedPreview = null, errorMessage = null) }
                            },
                            onClearFeedback = {
                                onUpdatePhonePatchLoadUiState {
                                    it.copy(errorMessage = null, lastCommitResult = null, lastMultiAudioReport = null)
                                }
                            },
                            onOpenStudioLibrary = { activePanel = ActivePanel.STUDIO_LIBRARY },
                            onClose = { activePanel = ActivePanel.NONE }
                        )
                        ActivePanel.MIDI -> MidiPanelContent(
                            settings = midiSettings,
                            status = midiStatus,
                            onRefresh = { midiManager.refreshDevices() },
                            onConnectDevice = { midiManager.connectDevice(it) },
                            onDisconnect = { midiManager.disconnect() },
                            onConnectBluetooth = {
                                onRequestBluetoothPermission()
                                midiManager.connectPairedBluetoothMidiDevices()
                            },
                            onUpdateSettings = { midiManager.updateSettings(it) },
                            onClose = { activePanel = ActivePanel.NONE }
                        )
                        ActivePanel.EFFECTS -> EffectsPanelContent(
                            effects = effects,
                            onUpdate = { transform ->
                                effectsProcessor.updateSettings(transform)
                                effectsProcessor.saveSettings()
                            },
                            onSave = { effectsProcessor.saveSettings() },
                            onRestore = { effectsProcessor.restoreSettings() },
                            onReset = { effectsProcessor.resetEffects() },
                            onClose = { activePanel = ActivePanel.NONE }
                        )
                        ActivePanel.PAD_EDITOR -> {
                            val padCfg = activePatch.pads.getOrNull(editingPadIndex) ?: activePatch.pads.first()
                            val factoryDefault = patchManager.getDefaultPadConfig(activePatch.number, editingPadIndex)
                            IndividualPadEditorPanel(
                                patchNumber = activePatch.number,
                                patchName = activePatch.name,
                                padConfig = padCfg,
                                defaultPadConfig = factoryDefault,
                                bundledLibrary = patchManager.bundledLibrary,
                                importedSounds = importedSounds,
                                padImportFeedback = padImportFeedback,
                                onAddOrChangeSampleFromPhone = {
                                    onClearImportFeedback()
                                    onLaunchAudioFilePicker(editingPadIndex)
                                },
                                onPreviewSample = { sampleKey, customSoundId, volume, pitch ->
                                    audioEngine.triggerPad(
                                        sampleKey = sampleKey,
                                        customSoundId = customSoundId,
                                        padVolume = volume,
                                        padPitch = pitch,
                                        velocity = 1.0f
                                    )
                                },
                                onSavePad = { updatedPad ->
                                    patchManager.savePadConfig(activePatch.number, updatedPad)
                                    activePanel = ActivePanel.NONE
                                },
                                onOpenFullPatchEditor = {
                                    activePanel = ActivePanel.PATCH_EDITOR
                                },
                                onCancel = {
                                    onClearImportFeedback()
                                    activePanel = ActivePanel.NONE
                                }
                            )
                        }
                        ActivePanel.PATCH_EDITOR -> PatchEditorPanel(
                            patch = activePatch,
                            categories = patchManager.categories,
                            bundledLibrary = patchManager.bundledLibrary,
                            importedSounds = importedSounds,
                            onPreviewSound = { sampleKey, customSoundId, volume, pitch ->
                                audioEngine.triggerPad(
                                    sampleKey = sampleKey,
                                    customSoundId = customSoundId,
                                    padVolume = volume,
                                    padPitch = pitch,
                                    velocity = 1.0f
                                )
                            },
                            onImportSound = { onLaunchAudioFilePicker(null) },
                            onSavePatch = { name, category, pads ->
                                patchManager.saveEditedPatch(activePatch.number, name, category, pads)
                                activePanel = ActivePanel.NONE
                            },
                            onSaveAsNewPatch = { targetNum, name, category, pads ->
                                patchManager.saveAsNewPatch(targetNum, name, category, pads)
                                activePanel = ActivePanel.NONE
                            },
                            onRenamePatch = { name ->
                                patchManager.renamePatch(activePatch.number, name)
                            },
                            onRestoreDefault = {
                                patchManager.resetPatchToDefault(activePatch.number)
                            },
                            onCancel = { activePanel = ActivePanel.NONE }
                        )
                        ActivePanel.STUDIO_LIBRARY -> StudioLibraryModal(
                            patches = patches,
                            activePatch = activePatch,
                            categories = patchManager.categories,
                            bundledLibrary = patchManager.bundledLibrary,
                            importedSounds = importedSounds,
                            kits = kits,
                            recorderState = recorderState,
                            recordings = recordings,
                            onSelectPatch = { patchManager.selectPatch(it) },
                            onRenamePatch = { num, name -> patchManager.renamePatch(num, name) },
                            onAssignBundled = { padIdx, key, label ->
                                patchManager.assignSoundToPad(activePatch.number, padIdx, key, label, null)
                            },
                            onAssignImported = { padIdx, snd ->
                                soundImportManager.assignToPad(activePatch.number, padIdx, snd)
                            },
                            onUpdatePadSettings = { padIdx, vol, pitch ->
                                patchManager.updatePadSettings(activePatch.number, padIdx, volume = vol, pitch = pitch)
                            },
                            onPreviewCustomSound = { soundImportManager.previewSound(it) },
                            onDeleteImportedSound = { soundImportManager.deleteImportedSound(it) },
                            onLaunchAudioPicker = { onLaunchAudioFilePicker(null) },
                            onSaveKit = { kitManager.saveCurrentAsKit(it) },
                            onLoadKit = { kitManager.loadKitIntoActivePatch(it) },
                            onRenameKit = { id, name -> kitManager.renameKit(id, name) },
                            onToggleFavKit = { kitManager.toggleFavorite(it) },
                            onDeleteKit = { kitManager.deleteKit(it) },
                            onRestoreDefaultKit = { kitManager.restoreDefaultActivePatch() },
                            onStartRecord = { recordingManager.startRecording() },
                            onStopRecord = { recordingManager.stopRecording() },
                            onSaveRecord = { recordingManager.saveCurrentRecording(it) },
                            onPlayRecord = { recordingManager.playRecording(it) },
                            onPauseRecord = { recordingManager.pausePlayback() },
                            onResumeRecord = { recordingManager.resumePlayback() },
                            onStopPlayback = { recordingManager.stopPlayback() },
                            onToggleLoop = { recordingManager.toggleLoop() },
                            onRenameRecord = { id, n -> recordingManager.renameRecording(id, n) },
                            onDeleteRecord = { recordingManager.deleteRecording(it) },
                            onClose = { activePanel = ActivePanel.NONE }
                        )
                        ActivePanel.NONE -> {}
                    }
                }
            }
        }
    }
}

@Composable
private fun PanelHeader(title: String, onClose: () -> Unit) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 10.dp)
    ) {
        Text(title, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        TextButton(onClick = onClose) {
            Text("Close", color = Color(0xFF7DD3FC), fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun EqPanelContent(
    eq: EqSettings,
    onUpdateEq: ((EqSettings) -> EqSettings) -> Unit,
    onSaveEq: () -> Unit,
    onResetEq: () -> Unit,
    onClose: () -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        PanelHeader("Real-Time 3-Band Equalizer", onClose)
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(bottom = 8.dp)) {
            Text("Equalizer Active", color = Color(0xFFE2E8F0), fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.width(12.dp))
            Switch(checked = eq.enabled, onCheckedChange = { onUpdateEq { s -> s.copy(enabled = it) } })
            Spacer(Modifier.weight(1f))
            Button(onClick = onResetEq, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF283446))) {
                Text("Reset EQ")
            }
            Spacer(Modifier.width(8.dp))
            Button(onClick = onSaveEq, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7))) {
                Text("Save EQ")
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.weight(1f)) {
            EqBandCard(
                title = "BASS",
                freqHz = eq.bassFreqHz,
                freqRange = 50f..300f,
                gainDb = eq.bassGainDb,
                onFreq = { f -> onUpdateEq { it.copy(bassFreqHz = f) } },
                onGain = { g -> onUpdateEq { it.copy(bassGainDb = g) } },
                modifier = Modifier.weight(1f)
            )
            EqBandCard(
                title = "MID",
                freqHz = eq.midFreqHz,
                freqRange = 350f..4500f,
                gainDb = eq.midGainDb,
                onFreq = { f -> onUpdateEq { it.copy(midFreqHz = f) } },
                onGain = { g -> onUpdateEq { it.copy(midGainDb = g) } },
                modifier = Modifier.weight(1f)
            )
            EqBandCard(
                title = "TREBLE",
                freqHz = eq.trebleFreqHz,
                freqRange = 4500f..14000f,
                gainDb = eq.trebleGainDb,
                onFreq = { f -> onUpdateEq { it.copy(trebleFreqHz = f) } },
                onGain = { g -> onUpdateEq { it.copy(trebleGainDb = g) } },
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun EqBandCard(
    title: String,
    freqHz: Float,
    freqRange: ClosedFloatingPointRange<Float>,
    gainDb: Float,
    onFreq: (Float) -> Unit,
    onGain: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxHeight()
            .clip(RoundedCornerShape(10.dp))
            .background(Color(0xFF151E2C))
            .border(1.dp, Color(0xFF2B3A52), RoundedCornerShape(10.dp))
            .padding(12.dp)
    ) {
        Text(title, color = Color(0xFF7DD3FC), fontWeight = FontWeight.Bold, fontSize = 14.sp)
        Spacer(Modifier.height(8.dp))
        Text("Gain: ${if (gainDb >= 0) "+" else ""}${String.format("%.1f", gainDb)} dB", color = Color.White, fontSize = 12.sp)
        Slider(
            value = gainDb,
            onValueChange = onGain,
            valueRange = -12f..12f,
            colors = SliderDefaults.colors(thumbColor = Color(0xFF38BDF8), activeTrackColor = Color(0xFF0284C7))
        )
        Spacer(Modifier.height(8.dp))
        Text("Frequency: ${freqHz.roundToInt()} Hz", color = Color(0xFFCBD5E1), fontSize = 12.sp)
        Slider(
            value = freqHz,
            onValueChange = onFreq,
            valueRange = freqRange,
            colors = SliderDefaults.colors(thumbColor = Color(0xFF38BDF8), activeTrackColor = Color(0xFF0284C7))
        )
    }
}

@Composable
private fun MidiPanelContent(
    settings: MidiSettings,
    status: MidiStatusState,
    onRefresh: () -> Unit,
    onConnectDevice: (Int) -> Unit,
    onDisconnect: () -> Unit,
    onConnectBluetooth: () -> Unit,
    onUpdateSettings: ((MidiSettings) -> MidiSettings) -> Unit,
    onClose: () -> Unit
) {
    Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        PanelHeader("Android MIDI Controller & Output", onClose)

        if (!status.isMidiSupported) {
            Text(
                text = "This Android device does not report android.software.midi support. External USB/BLE MIDI hardware cannot be opened on this hardware.",
                color = Color(0xFFFBBF24),
                fontSize = 12.sp,
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF2B2111))
                    .padding(10.dp)
            )
            Spacer(Modifier.height(8.dp))
        }

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
            Column(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xFF151E2C))
                    .padding(10.dp)
            ) {
                Text("Status: ${status.statusMessage}", color = Color(0xFF7DD3FC), fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                Text("MIDI Input: ${status.connectedInputName ?: "None"}", color = Color(0xFFCBD5E1), fontSize = 11.sp)
                Text("MIDI Output: ${status.connectedOutputName ?: "None"}", color = Color(0xFFCBD5E1), fontSize = 11.sp)
                if (status.lastIncomingNote != null) {
                    Text("Last Note In: ${status.lastIncomingNote}", color = Color(0xFF34D399), fontSize = 11.sp)
                }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = onRefresh, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B))) {
                        Text("Scan USB", fontSize = 11.sp)
                    }
                    Button(
                        onClick = onConnectBluetooth,
                        enabled = status.bluetoothSupported,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0369A1))
                    ) {
                        Text("BLE MIDI", fontSize = 11.sp)
                    }
                    Button(onClick = onDisconnect, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7F1D1D))) {
                        Text("Disconnect", fontSize = 11.sp)
                    }
                }
            }

            Column(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xFF151E2C))
                    .padding(10.dp)
            ) {
                Text("Channel: ${settings.channel}", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Slider(
                    value = settings.channel.toFloat(),
                    onValueChange = { ch -> onUpdateSettings { it.copy(channel = ch.roundToInt()) } },
                    valueRange = 1f..16f,
                    steps = 14
                )
                Text("Velocity Scale: ${(settings.velocityScale * 100).roundToInt()}%", color = Color.White, fontSize = 12.sp)
                Slider(
                    value = settings.velocityScale,
                    onValueChange = { vs -> onUpdateSettings { it.copy(velocityScale = vs) } },
                    valueRange = 0.25f..1.5f
                )
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("MIDI Out", color = Color.White, fontSize = 11.sp)
                    Switch(checked = settings.midiOutEnabled, onCheckedChange = { on -> onUpdateSettings { it.copy(midiOutEnabled = on) } })
                    Text("MIDI In", color = Color.White, fontSize = 11.sp)
                    Switch(checked = settings.midiInEnabled, onCheckedChange = { on -> onUpdateSettings { it.copy(midiInEnabled = on) } })
                }
            }
        }

        Spacer(Modifier.height(10.dp))
        Text("Detected MIDI Hardware Devices (${status.availableDevices.size})", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        if (status.availableDevices.isEmpty()) {
            Text("Connect a USB OTG MIDI controller/synth or pair a Bluetooth MIDI device.", color = Color(0xFF94A3B8), fontSize = 11.sp)
        } else {
            status.availableDevices.forEach { dev ->
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF182233))
                        .padding(8.dp)
                ) {
                    Column {
                        Text("${dev.name} (${dev.typeLabel})", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        Text("${dev.manufacturer} · In:${dev.hasOutputPort} Out:${dev.hasInputPort}", color = Color(0xFF94A3B8), fontSize = 10.sp)
                    }
                    Button(
                        onClick = { if (dev.isConnected) onDisconnect() else onConnectDevice(dev.id) },
                        colors = ButtonDefaults.buttonColors(containerColor = if (dev.isConnected) Color(0xFF16A34A) else Color(0xFF0284C7))
                    ) {
                        Text(if (dev.isConnected) "Connected" else "Connect", fontSize = 11.sp)
                    }
                }
            }
        }

        Spacer(Modifier.height(10.dp))
        Text("Pad MIDI Note Mapping (Pads 1–8)", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth().padding(top = 6.dp)) {
            for (i in 0 until 8) {
                val note = settings.padNotes.getOrElse(i) { 36 + i }
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF182233))
                        .padding(6.dp)
                ) {
                    Text("Pad ${i + 1}", color = Color(0xFF94A3B8), fontSize = 10.sp)
                    Text("$note", color = Color(0xFF7DD3FC), fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    Row {
                        Text("-", color = Color.White, modifier = Modifier.clickable {
                            val list = settings.padNotes.toMutableList()
                            list[i] = (note - 1).coerceIn(0, 127)
                            onUpdateSettings { it.copy(padNotes = list) }
                        }.padding(horizontal = 6.dp))
                        Text("+", color = Color.White, modifier = Modifier.clickable {
                            val list = settings.padNotes.toMutableList()
                            list[i] = (note + 1).coerceIn(0, 127)
                            onUpdateSettings { it.copy(padNotes = list) }
                        }.padding(horizontal = 6.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun QualityPanelContent(
    quality: QualitySettings,
    caps: AudioHardwareCapabilities,
    activeVoices: Int,
    onUpdateQuality: ((QualitySettings) -> QualitySettings) -> Unit,
    onRefresh: () -> Unit,
    onClose: () -> Unit
) {
    var touchCount by remember { mutableIntStateOf(0) }

    Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        PanelHeader("Audio Quality & Device Capabilities", onClose)

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
            Column(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xFF151E2C))
                    .padding(12.dp)
            ) {
                Text("Hardware Report", color = Color(0xFF7DD3FC), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Spacer(Modifier.height(6.dp))
                Text("Native Sample Rate: ${caps.nativeSampleRate} Hz", color = Color.White, fontSize = 12.sp)
                Text("Native Frames/Buffer: ${caps.nativeFramesPerBuffer}", color = Color.White, fontSize = 12.sp)
                Text("Active Rate / Buffer: ${caps.activeSampleRate} Hz / ${caps.activeBufferFrames} frames", color = Color(0xFF38BDF8), fontSize = 12.sp)
                Text("Low Latency Feature: ${if (caps.supportsLowLatency) "Supported" else "Standard Audio"}", color = Color(0xFFCBD5E1), fontSize = 11.sp)
                Text("Pro Audio Feature: ${if (caps.supportsProAudio) "Supported" else "No"}", color = Color(0xFFCBD5E1), fontSize = 11.sp)
                Text("Active Mixer Voices: $activeVoices / 24", color = Color(0xFFCBD5E1), fontSize = 11.sp)

                Spacer(Modifier.height(8.dp))
                Text("Supported Sample Rates", color = Color(0xFF94A3B8), fontSize = 11.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(top = 4.dp)) {
                    caps.supportedSampleRates.forEach { sr ->
                        val selected = quality.preferredSampleRate == sr
                        Button(
                            onClick = { onUpdateQuality { it.copy(preferredSampleRate = sr) } },
                            colors = ButtonDefaults.buttonColors(containerColor = if (selected) Color(0xFF0284C7) else Color(0xFF1E293B))
                        ) {
                            Text("$sr Hz", fontSize = 11.sp)
                        }
                    }
                }
            }

            Column(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xFF151E2C))
                    .padding(12.dp)
            ) {
                Text("Buffer Multiplier: ${quality.bufferFramesMultiplier}x (${caps.nativeFramesPerBuffer * quality.bufferFramesMultiplier} frames)", color = Color.White, fontSize = 12.sp)
                Slider(
                    value = quality.bufferFramesMultiplier.toFloat(),
                    onValueChange = { m -> onUpdateQuality { it.copy(bufferFramesMultiplier = m.roundToInt()) } },
                    valueRange = 1f..6f,
                    steps = 4
                )

                if (caps.supportsLowLatency) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Low-Latency AudioTrack Mode", color = Color.White, fontSize = 12.sp)
                        Spacer(Modifier.weight(1f))
                        Switch(
                            checked = quality.lowLatencyPreferred,
                            onCheckedChange = { on -> onUpdateQuality { it.copy(lowLatencyPreferred = on) } }
                        )
                    }
                }

                Spacer(Modifier.height(6.dp))
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                    Text("Audio Output Device", color = Color(0xFF94A3B8), fontSize = 11.sp)
                    Text("Refresh", color = Color(0xFF38BDF8), fontSize = 11.sp, modifier = Modifier.clickable(onClick = onRefresh))
                }
                caps.outputDevices.forEach { dev ->
                    val selected = quality.preferredOutputDeviceId == dev.id
                    Text(
                        text = "${if (selected) "● " else "○ "}${dev.name} (${dev.typeLabel})",
                        color = if (selected) Color(0xFF7DD3FC) else Color(0xFFCBD5E1),
                        fontSize = 11.sp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onUpdateQuality { it.copy(preferredOutputDeviceId = dev.id) } }
                            .padding(vertical = 3.dp)
                    )
                }
            }
        }

        Spacer(Modifier.height(10.dp))
        // Live Multitouch Hardware Test Area
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .fillMaxWidth()
                .height(84.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(Color(0xFF0B1626))
                .border(1.dp, Color(0xFF38BDF8), RoundedCornerShape(10.dp))
                .pointerInput(Unit) {
                    awaitPointerEventScope {
                        while (true) {
                            val ev = awaitPointerEvent()
                            touchCount = ev.changes.count { it.pressed }
                        }
                    }
                }
        ) {
            Text(
                text = "Multitouch Test Pad (Place multiple fingers here) · Active Simultaneous Fingers: $touchCount · Distinct Multitouch: ${if (caps.supportsMultitouchDistinct) "Supported" else "Standard"}",
                color = Color(0xFFBAE6FD),
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

@Composable
private fun EffectsPanelContent(
    effects: EffectsSettings,
    onUpdate: ((EffectsSettings) -> EffectsSettings) -> Unit,
    onSave: () -> Unit,
    onRestore: () -> Unit,
    onReset: () -> Unit,
    onClose: () -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        PanelHeader("Master Effects Processor", onClose)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(bottom = 12.dp)) {
            Button(onClick = onSave, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7))) { Text("Save Settings") }
            Button(onClick = onRestore, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B))) { Text("Restore Saved") }
            Button(onClick = onReset, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF475569))) { Text("Reset All") }
        }

        Row(
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .clip(RoundedCornerShape(12.dp))
                .background(Color(0xFF151E2C))
                .padding(14.dp)
        ) {
            RotaryKnob("Master Vol", effects.masterVolume, 0f, 1.5f, "${((effects.masterVolume / 1.5f) * 100).roundToInt()}%", { v -> onUpdate { it.copy(masterVolume = v) } }, 68.dp)
            RotaryKnob("Bass", effects.bassDb, -12f, 12f, "${effects.bassDb.roundToInt()} dB", { v -> onUpdate { it.copy(bassDb = v) } }, 68.dp)
            RotaryKnob("Treble", effects.trebleDb, -12f, 12f, "${effects.trebleDb.roundToInt()} dB", { v -> onUpdate { it.copy(trebleDb = v) } }, 68.dp)
            RotaryKnob("Pitch", effects.pitchMultiplier, 0.5f, 2.0f, "${String.format("%.2f", effects.pitchMultiplier)}x", { v -> onUpdate { it.copy(pitchMultiplier = v) } }, 68.dp)
            RotaryKnob("Echo", effects.echoMix, 0f, 1f, "${(effects.echoMix * 100).roundToInt()}%", { v -> onUpdate { it.copy(echoMix = v) } }, 68.dp)
            RotaryKnob("Delay", effects.delayMix, 0f, 1f, "${(effects.delayMix * 100).roundToInt()}%", { v -> onUpdate { it.copy(delayMix = v) } }, 68.dp)
            RotaryKnob("Reverb", effects.reverbMix, 0f, 1f, "${(effects.reverbMix * 100).roundToInt()}%", { v -> onUpdate { it.copy(reverbMix = v) } }, 68.dp)
        }
    }
}

@Composable
private fun StudioLibraryModal(
    patches: List<PatchSlot>,
    activePatch: PatchSlot,
    categories: List<String>,
    bundledLibrary: List<PatchManager.BundledSampleInfo>,
    importedSounds: List<ImportedSound>,
    kits: List<DrumKit>,
    recorderState: RecorderState,
    recordings: List<PerformanceRecording>,
    onSelectPatch: (Int) -> Unit,
    onRenamePatch: (Int, String) -> Unit,
    onAssignBundled: (Int, String, String) -> Unit,
    onAssignImported: (Int, ImportedSound) -> Unit,
    onUpdatePadSettings: (Int, Float?, Float?) -> Unit,
    onPreviewCustomSound: (String) -> Unit,
    onDeleteImportedSound: (String) -> Unit,
    onLaunchAudioPicker: () -> Unit,
    onSaveKit: (String) -> Unit,
    onLoadKit: (String) -> Unit,
    onRenameKit: (String, String) -> Unit,
    onToggleFavKit: (String) -> Unit,
    onDeleteKit: (String) -> Unit,
    onRestoreDefaultKit: () -> Unit,
    onStartRecord: () -> Unit,
    onStopRecord: () -> Unit,
    onSaveRecord: (String) -> Unit,
    onPlayRecord: (String) -> Unit,
    onPauseRecord: () -> Unit,
    onResumeRecord: () -> Unit,
    onStopPlayback: () -> Unit,
    onToggleLoop: () -> Unit,
    onRenameRecord: (String, String) -> Unit,
    onDeleteRecord: (String) -> Unit,
    onClose: () -> Unit
) {
    var tab by remember { mutableIntStateOf(0) }
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("All") }
    var renameInput by remember(activePatch.number) { mutableStateOf(activePatch.name) }
    var selectedPadForAssign by remember { mutableIntStateOf(0) }
    var kitNameInput by remember { mutableStateOf("") }
    var recNameInput by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
            val tabs = listOf("500 Patches & Pads", "Sound Import", "Custom Kits", "Recorder")
            tabs.forEachIndexed { idx, title ->
                Button(
                    onClick = { tab = idx },
                    colors = ButtonDefaults.buttonColors(containerColor = if (tab == idx) Color(0xFF0284C7) else Color(0xFF1E293B)),
                    modifier = Modifier.padding(end = 6.dp)
                ) {
                    Text(title, fontSize = 11.sp)
                }
            }
            Spacer(Modifier.weight(1f))
            TextButton(onClick = onClose) { Text("Close", color = Color(0xFF7DD3FC), fontWeight = FontWeight.Bold) }
        }

        when (tab) {
            0 -> {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.weight(1f)) {
                    // Left column: 500 Patches Search & Selection
                    Column(modifier = Modifier.weight(1f)) {
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            placeholder = { Text("Search 500 patches...", fontSize = 12.sp) },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedBorderColor = Color(0xFF38BDF8),
                                unfocusedBorderColor = Color(0xFF334155)
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                        val filtered = patches.filter { p ->
                            val matchesCat = selectedCategory == "All" || p.category == selectedCategory
                            val q = searchQuery.trim().lowercase()
                            val matchesQ = q.isEmpty() || p.name.lowercase().contains(q) || p.number.toString().padStart(3, '0').contains(q)
                            matchesCat && matchesQ
                        }
                        LazyColumn(modifier = Modifier.weight(1f).padding(top = 6.dp)) {
                            items(filtered, key = { "${it.number}_${it.id}" }) { slot ->
                                val isSel = slot.number == activePatch.number
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 2.dp)
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(if (isSel) Color(0xFF0284C7) else Color(0xFF151E2C))
                                        .clickable { onSelectPatch(slot.number) }
                                        .padding(horizontal = 8.dp, vertical = 6.dp)
                                ) {
                                    Text(slot.number.toString().padStart(3, '0'), color = Color(0xFFBAE6FD), fontFamily = FontFamily.Monospace, fontSize = 11.sp)
                                    Spacer(Modifier.width(8.dp))
                                    Text(slot.name, color = Color.White, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                                    Text(slot.category, color = Color(0xFF94A3B8), fontSize = 10.sp)
                                }
                            }
                        }
                    }

                    // Right column: Rename current patch & per-pad assignment/volume/pitch
                    Column(modifier = Modifier.weight(1f).verticalScroll(rememberScrollState())) {
                        Text("Patch ${activePatch.number.toString().padStart(3, '0')} (${activePatch.category})", color = Color(0xFF7DD3FC), fontWeight = FontWeight.Bold)
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 6.dp)) {
                            OutlinedTextField(
                                value = renameInput,
                                onValueChange = { renameInput = it },
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White),
                                modifier = Modifier.weight(1f)
                            )
                            Spacer(Modifier.width(6.dp))
                            Button(onClick = { onRenamePatch(activePatch.number, renameInput) }) { Text("Save Name", fontSize = 11.sp) }
                        }

                        Text("Select Pad to Configure (1–8):", color = Color(0xFFCBD5E1), fontSize = 11.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.padding(vertical = 4.dp)) {
                            for (p in 0..7) {
                                val sel = p == selectedPadForAssign
                                Box(
                                    contentAlignment = Alignment.Center,
                                    modifier = Modifier
                                        .size(34.dp)
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(if (sel) Color(0xFF0284C7) else Color(0xFF1E293B))
                                        .clickable { selectedPadForAssign = p }
                                ) {
                                    Text("${p + 1}", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                }
                            }
                        }

                        val curPad = activePatch.pads.getOrNull(selectedPadForAssign)
                        if (curPad != null) {
                            Text("Pad ${selectedPadForAssign + 1}: ${curPad.sampleName}", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                            Text("Pad Volume: ${(curPad.volume * 100).roundToInt()}%", color = Color(0xFF94A3B8), fontSize = 11.sp)
                            Slider(value = curPad.volume, onValueChange = { onUpdatePadSettings(selectedPadForAssign, it, null) }, valueRange = 0f..1.4f)
                            Text("Pad Pitch: ${String.format("%.2f", curPad.pitch)}x", color = Color(0xFF94A3B8), fontSize = 11.sp)
                            Slider(value = curPad.pitch, onValueChange = { onUpdatePadSettings(selectedPadForAssign, null, it) }, valueRange = 0.5f..2.0f)

                            Text("Assign Bundled Sound:", color = Color(0xFF7DD3FC), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            bundledLibrary.chunked(3).forEach { row ->
                                Row(horizontalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.padding(vertical = 2.dp)) {
                                    row.forEach { sample ->
                                        Button(
                                            onClick = { onAssignBundled(selectedPadForAssign, sample.key, sample.label) },
                                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Text(sample.label, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            1 -> {
                // Sound Import (WAV, MP3, OGG)
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Text("Import WAV, MP3, or OGG into local storage & assign to Pad ${selectedPadForAssign + 1}", color = Color(0xFFCBD5E1), fontSize = 12.sp)
                        Button(onClick = onLaunchAudioPicker, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7))) {
                            Text("Import Audio File")
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.padding(vertical = 8.dp)) {
                        Text("Target Pad:", color = Color.White, fontSize = 12.sp, modifier = Modifier.align(Alignment.CenterVertically))
                        for (p in 0..7) {
                            val sel = p == selectedPadForAssign
                            Button(
                                onClick = { selectedPadForAssign = p },
                                colors = ButtonDefaults.buttonColors(containerColor = if (sel) Color(0xFF0284C7) else Color(0xFF1E293B))
                            ) { Text("${p + 1}", fontSize = 11.sp) }
                        }
                    }
                    LazyColumn(modifier = Modifier.weight(1f)) {
                        items(importedSounds, key = { it.id }) { snd ->
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 3.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color(0xFF151E2C))
                                    .padding(8.dp)
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(snd.displayName, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                                    Text("${snd.fileName} · ${snd.durationMs} ms", color = Color(0xFF94A3B8), fontSize = 10.sp)
                                }
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Button(onClick = { onPreviewCustomSound(snd.id) }) { Text("Preview", fontSize = 10.sp) }
                                    Button(onClick = { onAssignImported(selectedPadForAssign, snd) }) { Text("Assign Pad ${selectedPadForAssign + 1}", fontSize = 10.sp) }
                                    Button(onClick = { onDeleteImportedSound(snd.id) }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7F1D1D))) { Text("Delete", fontSize = 10.sp) }
                                }
                            }
                        }
                    }
                }
            }
            2 -> {
                // Kit Management
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = kitNameInput,
                            onValueChange = { kitNameInput = it },
                            placeholder = { Text("New kit name...") },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White),
                            modifier = Modifier.weight(1f)
                        )
                        Button(onClick = { onSaveKit(kitNameInput); kitNameInput = "" }) { Text("Save Current Kit") }
                        Button(onClick = onRestoreDefaultKit, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF475569))) { Text("Restore Default") }
                    }
                    LazyColumn(modifier = Modifier.weight(1f).padding(top = 8.dp)) {
                        items(kits, key = { it.id }) { kit ->
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 3.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color(0xFF151E2C))
                                    .padding(8.dp)
                            ) {
                                Text(
                                    text = "${if (kit.isFavorite) "★ " else ""}${kit.name}",
                                    color = Color.White,
                                    fontWeight = FontWeight.SemiBold,
                                    modifier = Modifier.weight(1f)
                                )
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Button(onClick = { onToggleFavKit(kit.id) }) { Text(if (kit.isFavorite) "Unfav" else "Fav", fontSize = 10.sp) }
                                    Button(onClick = { onLoadKit(kit.id) }) { Text("Load", fontSize = 10.sp) }
                                    Button(onClick = { onDeleteKit(kit.id) }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7F1D1D))) { Text("Delete", fontSize = 10.sp) }
                                }
                            }
                        }
                    }
                }
            }
            3 -> {
                // Performance Recorder
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = { if (recorderState.isRecording) onStopRecord() else onStartRecord() },
                            colors = ButtonDefaults.buttonColors(containerColor = if (recorderState.isRecording) Color(0xFFDC2626) else Color(0xFF0284C7))
                        ) {
                            Text(if (recorderState.isRecording) "Stop Recording (${recorderState.recordedEventCount} hits)" else "Start Recording")
                        }
                        Button(onClick = onToggleLoop, colors = ButtonDefaults.buttonColors(containerColor = if (recorderState.isLooping) Color(0xFF16A34A) else Color(0xFF334155))) {
                            Text("Loop: ${if (recorderState.isLooping) "ON" else "OFF"}")
                        }
                        if (recorderState.playbackState == PlaybackState.PLAYING) {
                            Button(onClick = onPauseRecord) { Text("Pause") }
                            Button(onClick = onStopPlayback) { Text("Stop") }
                        } else if (recorderState.playbackState == PlaybackState.PAUSED) {
                            Button(onClick = onResumeRecord) { Text("Resume") }
                            Button(onClick = onStopPlayback) { Text("Stop") }
                        }
                    }

                    if (recorderState.hasUnsavedRecording) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(vertical = 8.dp)) {
                            OutlinedTextField(
                                value = recNameInput,
                                onValueChange = { recNameInput = it },
                                placeholder = { Text("Recording name...") },
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White),
                                modifier = Modifier.weight(1f)
                            )
                            Button(onClick = { onSaveRecord(recNameInput); recNameInput = "" }) { Text("Save Recording") }
                        }
                    }

                    LazyColumn(modifier = Modifier.weight(1f).padding(top = 8.dp)) {
                        items(recordings, key = { it.id }) { rec ->
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 3.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color(0xFF151E2C))
                                    .padding(8.dp)
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(rec.name, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                                    Text("${rec.events.size} hits · ${rec.durationMs} ms · Patch ${rec.patchNumber.toString().padStart(3, '0')}", color = Color(0xFF94A3B8), fontSize = 10.sp)
                                }
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Button(onClick = { onPlayRecord(rec.id) }) { Text("Play", fontSize = 10.sp) }
                                    Button(onClick = { onDeleteRecord(rec.id) }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7F1D1D))) { Text("Delete", fontSize = 10.sp) }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PatchEditorPanel(
    patch: PatchSlot,
    categories: List<String>,
    bundledLibrary: List<PatchManager.BundledSampleInfo>,
    importedSounds: List<ImportedSound>,
    onPreviewSound: (sampleKey: String, customSoundId: String?, volume: Float, pitch: Float) -> Unit,
    onImportSound: () -> Unit,
    onSavePatch: (name: String, category: String, pads: List<PadConfig>) -> Unit,
    onSaveAsNewPatch: (targetNumber: Int, name: String, category: String, pads: List<PadConfig>) -> Unit,
    onRenamePatch: (name: String) -> Unit,
    onRestoreDefault: () -> Unit,
    onCancel: () -> Unit
) {
    var draftName by remember(patch.number, patch.name) { mutableStateOf(patch.name) }
    var draftCategory by remember(patch.number, patch.category) { mutableStateOf(patch.category) }
    var draftPads by remember(patch.number, patch.pads) { mutableStateOf(patch.pads) }
    var selectedPadIdx by remember { mutableIntStateOf(0) }
    var saveAsSlotInput by remember(patch.number) {
        mutableStateOf((if (patch.number >= 500) 1 else patch.number + 1).toString().padStart(3, '0'))
    }
    var showSaveAsDialog by remember { mutableStateOf(false) }

    val selectedPad = draftPads.getOrElse(selectedPadIdx) { draftPads.first() }

    Column(modifier = Modifier.fillMaxSize()) {
        // Header Row: Patch Editor Title + Patch Number + Cancel / Restore / Save As New / Save Patch
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 8.dp)
        ) {
            Column {
                Text(
                    text = "PATCH EDITOR · Slot ${patch.number.toString().padStart(3, '0')}",
                    color = Color.White,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.ExtraBold
                )
                Text(
                    text = "$draftCategory · $draftName",
                    color = Color(0xFF7DD3FC),
                    fontSize = 11.sp
                )
            }
            Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.horizontalScroll(rememberScrollState())
            ) {
                Button(
                    onClick = onImportSound,
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0369A1))
                ) { Text("Import Sound", fontSize = 11.sp, maxLines = 1) }
                Button(
                    onClick = onRestoreDefault,
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF334155))
                ) { Text("Restore Default", fontSize = 11.sp, maxLines = 1) }
                Button(
                    onClick = { showSaveAsDialog = !showSaveAsDialog },
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1D4ED8))
                ) { Text("Save As New", fontSize = 11.sp, maxLines = 1) }
                Button(
                    onClick = { onSavePatch(draftName, draftCategory, draftPads) },
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF16A34A))
                ) { Text("Save Patch", fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1) }
                TextButton(onClick = onCancel) {
                    Text("Cancel", color = Color(0xFFFCA5A5), fontWeight = FontWeight.Bold, maxLines = 1)
                }
            }
        }

        if (showSaveAsDialog) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF17253B))
                    .border(1.dp, Color(0xFF38BDF8), RoundedCornerShape(8.dp))
                    .padding(8.dp)
            ) {
                Text("Save As Patch Slot (001–500):", color = Color.White, fontSize = 12.sp)
                OutlinedTextField(
                    value = saveAsSlotInput,
                    onValueChange = { saveAsSlotInput = it.filter { ch -> ch.isDigit() }.take(3) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White),
                    modifier = Modifier.width(88.dp)
                )
                Button(
                    onClick = {
                        val target = saveAsSlotInput.toIntOrNull()?.coerceIn(1, 500) ?: patch.number
                        onSaveAsNewPatch(target, draftName, draftCategory, draftPads)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7))
                ) { Text("Confirm Save As", fontSize = 11.sp) }
            }
        }

        // Patch Name, Rename Patch, and Patch Category Selector
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
        ) {
            OutlinedTextField(
                value = draftName,
                onValueChange = { draftName = it.take(36) },
                label = { Text("Patch Name", fontSize = 10.sp) },
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    focusedBorderColor = Color(0xFF38BDF8),
                    unfocusedBorderColor = Color(0xFF334155)
                ),
                modifier = Modifier.weight(0.42f)
            )
            Button(
                onClick = { onRenamePatch(draftName) },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B))
            ) { Text("Rename Patch", fontSize = 11.sp) }

            Row(
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                modifier = Modifier
                    .weight(0.58f)
                    .horizontalScroll(rememberScrollState())
            ) {
                categories.forEach { cat ->
                    val isCat = cat == draftCategory
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (isCat) Color(0xFF0284C7) else Color(0xFF182233))
                            .border(1.dp, if (isCat) Color(0xFF7DD3FC) else Color(0xFF334155), RoundedCornerShape(6.dp))
                            .clickable { draftCategory = cat }
                            .padding(horizontal = 8.dp, vertical = 6.dp)
                    ) {
                        Text(cat, color = Color.White, fontSize = 10.5.sp, maxLines = 1)
                    }
                }
            }
        }

        // Main Split: Left (All 8 Pads Overview) + Right (Selected Pad Sound, Preview, Volume, Pitch, MIDI Note, Sound Picker)
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.weight(1f)) {
            // Left: Pad 1..8 Cards
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(5.dp),
                modifier = Modifier.weight(0.43f).fillMaxHeight()
            ) {
                items(draftPads, key = { it.padIndex }) { pad ->
                    val isSel = pad.padIndex == selectedPadIdx
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isSel) Color(0xFF103E7A) else Color(0xFF151E2C))
                            .border(
                                width = if (isSel) 1.5.dp else 1.dp,
                                color = if (isSel) Color(0xFF38BDF8) else Color(0xFF283447),
                                shape = RoundedCornerShape(8.dp)
                            )
                            .clickable { selectedPadIdx = pad.padIndex }
                            .padding(horizontal = 10.dp, vertical = 7.dp)
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Pad ${pad.padIndex + 1} Sound · ${pad.sampleName}",
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "Vol ${(pad.volume * 100).roundToInt()}% · Pitch ${String.format("%.2f", pad.pitch)}x · MIDI ${pad.midiNote}",
                                color = Color(0xFF94A3B8),
                                fontSize = 10.sp
                            )
                        }
                        Button(
                            onClick = {
                                selectedPadIdx = pad.padIndex
                                onPreviewSound(pad.sampleKey, pad.customSoundId, pad.volume, pad.pitch)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7))
                        ) {
                            Text("Preview", fontSize = 10.sp)
                        }
                    }
                }
            }

            // Right: Selected Pad Detailed Controls & Original 18 WAV + Imported Sound Selector
            Column(
                modifier = Modifier
                    .weight(0.57f)
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xFF151E2C))
                    .border(1.dp, Color(0xFF2B3A52), RoundedCornerShape(10.dp))
                    .padding(10.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Editing Pad ${selectedPad.padIndex + 1}: ${selectedPad.sampleName}",
                        color = Color(0xFF7DD3FC),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Button(
                        onClick = {
                            onPreviewSound(
                                selectedPad.sampleKey,
                                selectedPad.customSoundId,
                                selectedPad.volume,
                                selectedPad.pitch
                            )
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7))
                    ) { Text("Preview Sound", fontSize = 11.sp) }
                }

                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Volume: ${(selectedPad.volume * 100).roundToInt()}%", color = Color.White, fontSize = 11.sp)
                        Slider(
                            value = selectedPad.volume,
                            onValueChange = { v ->
                                draftPads = draftPads.map {
                                    if (it.padIndex == selectedPadIdx) it.copy(volume = v) else it
                                }
                            },
                            valueRange = 0f..1.4f
                        )
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Pitch: ${String.format("%.2f", selectedPad.pitch)}x", color = Color.White, fontSize = 11.sp)
                        Slider(
                            value = selectedPad.pitch,
                            onValueChange = { p ->
                                draftPads = draftPads.map {
                                    if (it.padIndex == selectedPadIdx) it.copy(pitch = p) else it
                                }
                            },
                            valueRange = 0.5f..2.0f
                        )
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(114.dp)) {
                        Text("MIDI Note", color = Color.White, fontSize = 11.sp)
                        Spacer(Modifier.height(6.dp))
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier
                                    .size(28.dp)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(Color(0xFF1E293B))
                                    .border(1.dp, Color(0xFF334155), RoundedCornerShape(6.dp))
                                    .clickable {
                                        draftPads = draftPads.map {
                                            if (it.padIndex == selectedPadIdx) it.copy(midiNote = (it.midiNote - 1).coerceIn(0, 127)) else it
                                        }
                                    }
                            ) {
                                Text("-", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                            }
                            Text(
                                text = "${selectedPad.midiNote}",
                                color = Color(0xFF7DD3FC),
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier
                                    .size(28.dp)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(Color(0xFF1E293B))
                                    .border(1.dp, Color(0xFF334155), RoundedCornerShape(6.dp))
                                    .clickable {
                                        draftPads = draftPads.map {
                                            if (it.padIndex == selectedPadIdx) it.copy(midiNote = (it.midiNote + 1).coerceIn(0, 127)) else it
                                        }
                                    }
                            ) {
                                Text("+", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                Spacer(Modifier.height(6.dp))
                Text("Select / Replace with Original Bundled Samples (18 WAVs):", color = Color(0xFFBAE6FD), fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(4.dp))
                bundledLibrary.chunked(3).forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(5.dp), modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
                        row.forEach { sample ->
                            val isAssigned = selectedPad.customSoundId == null && selectedPad.sampleKey == sample.key
                            Button(
                                onClick = {
                                    draftPads = draftPads.map {
                                        if (it.padIndex == selectedPadIdx) {
                                            it.copy(sampleKey = sample.key, sampleName = sample.label, customSoundId = null)
                                        } else it
                                    }
                                    onPreviewSound(sample.key, null, selectedPad.volume, selectedPad.pitch)
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isAssigned) Color(0xFF0284C7) else Color(0xFF1E293B)
                                ),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(sample.label, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    }
                }

                if (importedSounds.isNotEmpty()) {
                    Spacer(Modifier.height(8.dp))
                    Text("Custom Imported Sounds:", color = Color(0xFF34D399), fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
                    importedSounds.forEach { snd ->
                        val isAssigned = selectedPad.customSoundId == snd.id
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 2.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (isAssigned) Color(0xFF0F3D2E) else Color(0xFF1E293B))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(snd.displayName, color = Color.White, fontSize = 11.sp, modifier = Modifier.weight(1f))
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                Button(onClick = { onPreviewSound("custom", snd.id, selectedPad.volume, selectedPad.pitch) }) {
                                    Text("Preview", fontSize = 10.sp)
                                }
                                Button(onClick = {
                                    draftPads = draftPads.map {
                                        if (it.padIndex == selectedPadIdx) {
                                            it.copy(sampleKey = "custom", sampleName = snd.displayName, customSoundId = snd.id)
                                        } else it
                                    }
                                }) {
                                    Text("Assign", fontSize = 10.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun IndividualPadEditorPanel(
    patchNumber: Int,
    patchName: String,
    padConfig: PadConfig,
    defaultPadConfig: PadConfig,
    bundledLibrary: List<PatchManager.BundledSampleInfo>,
    importedSounds: List<ImportedSound>,
    padImportFeedback: PadImportFeedback?,
    onAddOrChangeSampleFromPhone: () -> Unit,
    onPreviewSample: (sampleKey: String, customSoundId: String?, volume: Float, pitch: Float) -> Unit,
    onSavePad: (PadConfig) -> Unit,
    onOpenFullPatchEditor: () -> Unit,
    onCancel: () -> Unit
) {
    var draft by remember(patchNumber, padConfig.padIndex) { mutableStateOf(padConfig) }

    // Automatically update draft when Android file picker imports a sample for this pad
    LaunchedEffect(padImportFeedback?.eventId) {
        val fb = padImportFeedback ?: return@LaunchedEffect
        if (!fb.isError && fb.padIndex == padConfig.padIndex && fb.importedSound != null) {
            draft = draft.copy(
                sampleKey = "custom",
                sampleName = fb.importedSound.displayName,
                customSoundId = fb.importedSound.id
            )
        }
    }

    val isCustomAssigned = draft.customSoundId != null

    Column(modifier = Modifier.fillMaxSize()) {
        // Header Row: Pad Number, Current Patch Info, SAVE & CANCEL buttons
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 8.dp)
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "PAD ${padConfig.padIndex + 1} EDITOR · Patch ${patchNumber.toString().padStart(3, '0')} ($patchName)",
                    color = Color.White,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.ExtraBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "Current Sample: ${draft.sampleName} (${if (isCustomAssigned) "Custom Phone Sample" else "Original Bundled WAV"})",
                    color = if (isCustomAssigned) Color(0xFF6EE7B7) else Color(0xFF7DD3FC),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Button(
                    onClick = onOpenFullPatchEditor,
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B))
                ) { Text("Patch Metadata", fontSize = 11.sp) }
                Button(
                    onClick = { onSavePad(draft) },
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF16A34A))
                ) { Text("SAVE", fontSize = 12.sp, fontWeight = FontWeight.ExtraBold) }
                Button(
                    onClick = onCancel,
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF334155))
                ) { Text("CANCEL", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFFFCA5A5)) }
            }
        }

        // Import Feedback Banner (Success or Error)
        if (padImportFeedback != null) {
            Text(
                text = padImportFeedback.message,
                color = if (padImportFeedback.isError) Color(0xFFFECACA) else Color(0xFFA7F3D0),
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (padImportFeedback.isError) Color(0xFF7F1D1D) else Color(0xFF064E3B))
                    .border(
                        1.dp,
                        if (padImportFeedback.isError) Color(0xFFF87171) else Color(0xFF34D399),
                        RoundedCornerShape(8.dp)
                    )
                    .padding(horizontal = 10.dp, vertical = 6.dp)
            )
        }

        // Phone Sample Action Toolbar: ADD SAMPLE | CHANGE SAMPLE | PREVIEW SAMPLE | REMOVE CUSTOM SAMPLE
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 10.dp)
                .horizontalScroll(rememberScrollState())
        ) {
            Button(
                onClick = onAddOrChangeSampleFromPhone,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7))
            ) { Text("ADD SAMPLE", fontSize = 11.5.sp, fontWeight = FontWeight.ExtraBold) }

            Button(
                onClick = onAddOrChangeSampleFromPhone,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1D4ED8))
            ) { Text("CHANGE SAMPLE", fontSize = 11.5.sp, fontWeight = FontWeight.ExtraBold) }

            Button(
                onClick = {
                    onPreviewSample(draft.sampleKey, draft.customSoundId, draft.volume, draft.pitch)
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0F766E))
            ) { Text("PREVIEW SAMPLE", fontSize = 11.5.sp, fontWeight = FontWeight.ExtraBold) }

            Button(
                onClick = {
                    draft = draft.copy(
                        sampleKey = defaultPadConfig.sampleKey,
                        sampleName = defaultPadConfig.sampleName,
                        customSoundId = null
                    )
                },
                enabled = isCustomAssigned || draft.sampleKey != defaultPadConfig.sampleKey,
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF7F1D1D),
                    disabledContainerColor = Color(0xFF1E293B)
                )
            ) { Text("REMOVE CUSTOM SAMPLE", fontSize = 11.5.sp, fontWeight = FontWeight.Bold) }
        }

        // Pad Volume, Pad Pitch & MIDI Note Controls
        Row(
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(Color(0xFF151E2C))
                .border(1.dp, Color(0xFF2B3A52), RoundedCornerShape(10.dp))
                .padding(horizontal = 12.dp, vertical = 10.dp)
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text("Pad Volume: ${(draft.volume * 100).roundToInt()}%", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                Slider(
                    value = draft.volume,
                    onValueChange = { draft = draft.copy(volume = it) },
                    valueRange = 0f..1.4f,
                    colors = SliderDefaults.colors(thumbColor = Color(0xFF38BDF8), activeTrackColor = Color(0xFF0284C7))
                )
            }
            Column(modifier = Modifier.weight(1f)) {
                Text("Pad Pitch: ${String.format("%.2f", draft.pitch)}x", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                Slider(
                    value = draft.pitch,
                    onValueChange = { draft = draft.copy(pitch = it) },
                    valueRange = 0.5f..2.0f,
                    colors = SliderDefaults.colors(thumbColor = Color(0xFF38BDF8), activeTrackColor = Color(0xFF0284C7))
                )
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(124.dp)) {
                Text("MIDI Note", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(6.dp))
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(30.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(Color(0xFF1E293B))
                            .border(1.dp, Color(0xFF334155), RoundedCornerShape(6.dp))
                            .clickable { draft = draft.copy(midiNote = (draft.midiNote - 1).coerceIn(0, 127)) }
                    ) {
                        Text("-", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    }
                    Text(
                        text = "${draft.midiNote}",
                        color = Color(0xFF7DD3FC),
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(30.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(Color(0xFF1E293B))
                            .border(1.dp, Color(0xFF334155), RoundedCornerShape(6.dp))
                            .clickable { draft = draft.copy(midiNote = (draft.midiNote + 1).coerceIn(0, 127)) }
                    ) {
                        Text("+", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        Spacer(Modifier.height(10.dp))

        // Bottom Scrollable Area: Imported Phone Samples + Preserved Original 18 WAV Samples
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.weight(1f)) {
            Column(
                modifier = Modifier
                    .weight(0.45f)
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xFF151E2C))
                    .border(1.dp, Color(0xFF2B3A52), RoundedCornerShape(10.dp))
                    .padding(10.dp)
            ) {
                Text(
                    text = "Imported Phone Samples (${importedSounds.size})",
                    color = Color(0xFF6EE7B7),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(bottom = 6.dp)
                )
                if (importedSounds.isEmpty()) {
                    Text(
                        text = "No custom audio imported yet. Tap ADD SAMPLE above to open your phone file picker (WAV, MP3, OGG).",
                        color = Color(0xFF94A3B8),
                        fontSize = 11.sp
                    )
                } else {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.weight(1f)) {
                        items(importedSounds, key = { it.id }) { snd ->
                            val isSel = draft.customSoundId == snd.id
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(if (isSel) Color(0xFF065F46) else Color(0xFF1E293B))
                                    .border(1.dp, if (isSel) Color(0xFF34D399) else Color.Transparent, RoundedCornerShape(6.dp))
                                    .padding(horizontal = 8.dp, vertical = 5.dp)
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(snd.displayName, color = Color.White, fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text("${snd.fileName} · ${snd.durationMs} ms", color = Color(0xFF94A3B8), fontSize = 9.5.sp, maxLines = 1)
                                }
                                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Button(
                                        onClick = { onPreviewSample("custom", snd.id, draft.volume, draft.pitch) },
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0F766E))
                                    ) { Text("Play", fontSize = 10.sp) }
                                    Button(
                                        onClick = {
                                            draft = draft.copy(sampleKey = "custom", sampleName = snd.displayName, customSoundId = snd.id)
                                            onPreviewSample("custom", snd.id, draft.volume, draft.pitch)
                                        },
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7))
                                    ) { Text("Use", fontSize = 10.sp) }
                                }
                            }
                        }
                    }
                }
            }

            Column(
                modifier = Modifier
                    .weight(0.55f)
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xFF151E2C))
                    .border(1.dp, Color(0xFF2B3A52), RoundedCornerShape(10.dp))
                    .padding(10.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    text = "Original Bundled Samples (18 WAVs)",
                    color = Color(0xFFBAE6FD),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(bottom = 6.dp)
                )
                bundledLibrary.chunked(3).forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(5.dp), modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
                        row.forEach { sample ->
                            val isAssigned = draft.customSoundId == null && draft.sampleKey == sample.key
                            Button(
                                onClick = {
                                    draft = draft.copy(sampleKey = sample.key, sampleName = sample.label, customSoundId = null)
                                    onPreviewSample(sample.key, null, draft.volume, draft.pitch)
                                },
                                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 4.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isAssigned) Color(0xFF0284C7) else Color(0xFF1E293B)
                                ),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(sample.label, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    }
                }
            }
        }
    }
}

private enum class PatchLoadTab {
    LIBRARY, SAMPLES, STAGED_IMPORT
}

@Composable
private fun PatchLoadPanel(
    patches: List<PatchSlot>,
    activePatchNumber: Int,
    activePatch: PatchSlot,
    categories: List<String>,
    bundledLibrary: List<PatchManager.BundledSampleInfo>,
    importedSounds: List<ImportedSound>,
    phonePatchLoadUiState: PhonePatchLoadUiState,
    isFactoryCustomized: (Int) -> Boolean,
    onSelectPatch: (Int) -> Unit,
    onPreviousPatch: () -> Unit,
    onNextPatch: () -> Unit,
    onDeleteImportedPatch: (Int) -> Boolean,
    onRestoreOriginalPatch: (Int) -> Unit,
    onLaunchMultiWavPicker: () -> Unit,
    onLaunchMultiMp3Picker: () -> Unit,
    onLaunchZipPackPicker: () -> Unit,
    onLaunchJsonPatchPicker: () -> Unit,
    onLaunchMissingSamplePicker: (missingFilename: String) -> Unit,
    onPreviewSound: (sampleKey: String, customSoundId: String?, volume: Float, pitch: Float) -> Unit,
    onAssignSoundToPad: (padIndex: Int, sound: ImportedSound) -> Unit,
    onSaveActivePadsAsImportedPatch: (name: String) -> Unit,
    onResolveMissingWithSound: (missingFilename: String, sound: ImportedSound) -> Unit,
    onResolveMissingWithBundled: (missingFilename: String, bundled: PatchManager.BundledSampleInfo) -> Unit,
    onCommitStagedPreview: (singlePatchLocalId: String?) -> Unit,
    onCancelStagedPreview: () -> Unit,
    onClearFeedback: () -> Unit,
    onOpenStudioLibrary: () -> Unit,
    onClose: () -> Unit
) {
    var activeTab by remember { mutableStateOf(PatchLoadTab.LIBRARY) }
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("All") }
    var onlyImportedFilter by remember { mutableStateOf(false) }
    var pendingDeletePatch by remember { mutableStateOf<PatchSlot?>(null) }
    var newPatchSaveName by remember { mutableStateOf("") }
    var missingResolverTarget by remember { mutableStateOf<String?>(null) }

    val importedCount = patches.count { it.isImported }

    // Auto-switch into Staged Import Preview whenever ZIP/JSON picker completes
    LaunchedEffect(phonePatchLoadUiState.stagedPreview?.previewId) {
        if (phonePatchLoadUiState.stagedPreview != null) {
            activeTab = PatchLoadTab.STAGED_IMPORT
        }
    }

    // Auto-switch into Multi-Sample view after multi WAV/MP3 batch import
    LaunchedEffect(phonePatchLoadUiState.lastMultiAudioReport) {
        if (phonePatchLoadUiState.lastMultiAudioReport != null && phonePatchLoadUiState.stagedPreview == null) {
            activeTab = PatchLoadTab.SAMPLES
        }
    }

    val listState = rememberLazyListState(
        initialFirstVisibleItemIndex = (activePatchNumber - 2).coerceIn(0, (patches.size - 1).coerceAtLeast(0))
    )

    val filtered = patches.filter { p ->
        val matchesImported = !onlyImportedFilter || p.isImported
        val matchesCat = selectedCategory == "All" || p.category == selectedCategory
        val q = searchQuery.trim().lowercase()
        val matchesQ = q.isEmpty() ||
            p.name.lowercase().contains(q) ||
            p.category.lowercase().contains(q) ||
            (p.sourcePackName?.lowercase()?.contains(q) == true) ||
            p.number.toString().padStart(3, '0').contains(q)
        matchesImported && matchesCat && matchesQ
    }

    LaunchedEffect(activePatchNumber, onlyImportedFilter) {
        val visible = listState.layoutInfo.visibleItemsInfo.map { it.index }
        val idxInFiltered = filtered.indexOfFirst { it.number == activePatchNumber }
        if (idxInFiltered >= 0 && idxInFiltered !in visible) {
            listState.animateScrollToItem((idxInFiltered - 1).coerceAtLeast(0))
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        // Header: PATCH LOAD + Active Slot + ⏪ / ⏩ / Kits & Recorder / Close
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 6.dp)
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "PATCH LOAD · ${activePatchNumber.toString().padStart(3, '0')} / ${patches.size} (${importedCount} Imported)",
                    color = Color.White,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.ExtraBold
                )
                Text(
                    text = "Active: ${activePatch.category} · ${activePatch.name}",
                    color = if (activePatch.isImported) Color(0xFF6EE7B7) else Color(0xFF7DD3FC),
                    fontSize = 11.5.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                HardwareArrowNavButton(
                    isPrevious = true,
                    contentDescription = "Previous Patch",
                    onClick = onPreviousPatch,
                    modifier = Modifier.width(54.dp).height(36.dp)
                )
                HardwareArrowNavButton(
                    isPrevious = false,
                    contentDescription = "Next Patch",
                    onClick = onNextPatch,
                    modifier = Modifier.width(54.dp).height(36.dp)
                )
                Button(
                    onClick = onOpenStudioLibrary,
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0369A1))
                ) { Text("Kits & Recorder", fontSize = 11.sp) }
                TextButton(onClick = onClose) {
                    Text("Close", color = Color(0xFF7DD3FC), fontWeight = FontWeight.Bold)
                }
            }
        }

        // Primary 5 Phone Patch Load Options Row (SAF Android Storage Pickers + Library)
        Row(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 8.dp)
        ) {
            PhoneImportActionButton(
                label = "1. LOAD WAV SAMPLES",
                containerColor = Color(0xFF0284C7),
                onClick = {
                    onClearFeedback()
                    onLaunchMultiWavPicker()
                },
                modifier = Modifier.weight(1f)
            )
            PhoneImportActionButton(
                label = "2. LOAD MP3 SAMPLES",
                containerColor = Color(0xFF0369A1),
                onClick = {
                    onClearFeedback()
                    onLaunchMultiMp3Picker()
                },
                modifier = Modifier.weight(1f)
            )
            PhoneImportActionButton(
                label = "3. LOAD ZIP PATCH PACK",
                containerColor = Color(0xFF1D4ED8),
                onClick = {
                    onClearFeedback()
                    onLaunchZipPackPicker()
                },
                modifier = Modifier.weight(1f)
            )
            PhoneImportActionButton(
                label = "4. LOAD JSON PATCH FILE",
                containerColor = Color(0xFF0F766E),
                onClick = {
                    onClearFeedback()
                    onLaunchJsonPatchPicker()
                },
                modifier = Modifier.weight(1f)
            )
            PhoneImportActionButton(
                label = "5. MY IMPORTED PATCHES ($importedCount)",
                containerColor = if (onlyImportedFilter && activeTab == PatchLoadTab.LIBRARY) Color(0xFF16A34A) else Color(0xFF1E293B),
                onClick = {
                    onlyImportedFilter = true
                    selectedCategory = "All"
                    activeTab = PatchLoadTab.LIBRARY
                },
                modifier = Modifier.weight(1.1f)
            )
        }

        // Busy Spinner / Error / Commit Summary Banners
        if (phonePatchLoadUiState.isBusy) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 6.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF0C2A4E))
                    .border(1.dp, Color(0xFF38BDF8), RoundedCornerShape(8.dp))
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                CircularProgressIndicator(
                    color = Color(0xFF38BDF8),
                    strokeWidth = 2.5.dp,
                    modifier = Modifier.size(18.dp)
                )
                Text(
                    text = phonePatchLoadUiState.busyMessage,
                    color = Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }

        phonePatchLoadUiState.errorMessage?.let { errMsg ->
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 6.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF7F1D1D))
                    .border(1.dp, Color(0xFFFCA5A5), RoundedCornerShape(8.dp))
                    .padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
                Text(
                    text = errMsg,
                    color = Color(0xFFFEE2E2),
                    fontSize = 11.5.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.weight(1f)
                )
                TextButton(onClick = onClearFeedback) {
                    Text("Dismiss", color = Color.White, fontSize = 11.sp)
                }
            }
        }

        phonePatchLoadUiState.lastCommitResult?.let { commit ->
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 6.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF064E3B))
                    .border(1.dp, Color(0xFF6EE7B7), RoundedCornerShape(8.dp))
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "IMPORT SUMMARY · ${commit.summaryMessage}",
                        color = Color(0xFFA7F3D0),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                    TextButton(onClick = onClearFeedback) {
                        Text("OK", color = Color.White, fontSize = 11.sp)
                    }
                }
                Text(
                    text = "Total found: ${commit.totalPatchesFound} · Imported: ${commit.successfullyImported.size} · Missing samples: ${commit.missingSamples.size} · Failed: ${commit.failedPatches.size}",
                    color = Color.White,
                    fontSize = 11.sp
                )
            }
        }

        // Sub-view Switcher: Unified Patch Library | Multi-Sample Manager | Staged ZIP/JSON Preview
        Row(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 6.dp)
        ) {
            listOf(
                PatchLoadTab.LIBRARY to "Patch Library (${patches.size})",
                PatchLoadTab.SAMPLES to "Imported Audio (${importedSounds.size})",
                PatchLoadTab.STAGED_IMPORT to if (phonePatchLoadUiState.stagedPreview != null) {
                    "Import Preview (${phonePatchLoadUiState.stagedPreview.stagedPatches.size})"
                } else {
                    "ZIP / JSON Preview"
                }
            ).forEach { (tab, label) ->
                val selected = activeTab == tab
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (selected) Color(0xFF1D8BFF) else Color(0xFF151E2C))
                        .border(1.dp, if (selected) Color(0xFF7DD3FC) else Color(0xFF334155), RoundedCornerShape(6.dp))
                        .clickable { activeTab = tab }
                        .padding(horizontal = 10.dp, vertical = 5.dp)
                ) {
                    Text(label, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        when (activeTab) {
            PatchLoadTab.LIBRARY -> {
                // Search, All/Imported filter & Categories
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 6.dp)
                ) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = { Text("Search ${patches.size} patches by slot, name, pack, style...", fontSize = 11.5.sp) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = Color(0xFF38BDF8),
                            unfocusedBorderColor = Color(0xFF334155)
                        ),
                        modifier = Modifier.weight(0.38f)
                    )
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        modifier = Modifier
                            .weight(0.62f)
                            .horizontalScroll(rememberScrollState())
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (!onlyImportedFilter) Color(0xFF0284C7) else Color(0xFF182233))
                                .border(1.dp, if (!onlyImportedFilter) Color(0xFF7DD3FC) else Color(0xFF334155), RoundedCornerShape(6.dp))
                                .clickable { onlyImportedFilter = false }
                                .padding(horizontal = 8.dp, vertical = 6.dp)
                        ) {
                            Text("All (${patches.size})", color = Color.White, fontSize = 10.5.sp, maxLines = 1)
                        }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (onlyImportedFilter) Color(0xFF16A34A) else Color(0xFF182233))
                                .border(1.dp, if (onlyImportedFilter) Color(0xFF86EFAC) else Color(0xFF334155), RoundedCornerShape(6.dp))
                                .clickable { onlyImportedFilter = true }
                                .padding(horizontal = 8.dp, vertical = 6.dp)
                        ) {
                            Text("Imported ($importedCount)", color = Color.White, fontSize = 10.5.sp, maxLines = 1)
                        }
                        (listOf("All") + categories + listOf("ZIP Pack", "Imported Phone")).distinct().forEach { cat ->
                            val isCat = cat == selectedCategory
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(if (isCat) Color(0xFF0284C7) else Color(0xFF182233))
                                    .border(1.dp, if (isCat) Color(0xFF7DD3FC) else Color(0xFF334155), RoundedCornerShape(6.dp))
                                    .clickable { selectedCategory = cat }
                                    .padding(horizontal = 8.dp, vertical = 6.dp)
                            ) {
                                Text(cat, color = Color.White, fontSize = 10.5.sp, maxLines = 1)
                            }
                        }
                    }
                }

                // Finger-Scrollable Unified Patch List
                LazyColumn(
                    state = listState,
                    verticalArrangement = Arrangement.spacedBy(5.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                ) {
                    if (filtered.isEmpty()) {
                        item {
                            Text(
                                text = if (onlyImportedFilter) {
                                    "No phone patches imported yet. Use LOAD ZIP PATCH PACK, LOAD JSON PATCH FILE, or LOAD WAV/MP3 SAMPLES above."
                                } else {
                                    "No patches match '$searchQuery'."
                                },
                                color = Color(0xFF94A3B8),
                                fontSize = 12.sp,
                                modifier = Modifier.padding(16.dp)
                            )
                        }
                    }
                    items(filtered, key = { "${it.number}_${it.id}" }) { slot ->
                        val isSelected = slot.number == activePatchNumber
                        val isCustomizedFactory = isFactoryCustomized(slot.number)
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) Color(0xFF1D8BFF) else Color(0xFF141D2B))
                                .border(
                                    width = if (isSelected) 1.5.dp else 1.dp,
                                    color = when {
                                        isSelected -> Color(0xFF93C5FD)
                                        slot.isImported -> Color(0xFF10B981).copy(alpha = 0.6f)
                                        else -> Color(0xFF263348)
                                    },
                                    shape = RoundedCornerShape(8.dp)
                                )
                                .clickable { onSelectPatch(slot.number) }
                                .padding(horizontal = 10.dp, vertical = 7.dp)
                        ) {
                            Text(
                                text = slot.number.toString().padStart(3, '0'),
                                color = when {
                                    isSelected -> Color.White
                                    slot.isImported -> Color(0xFF6EE7B7)
                                    else -> Color(0xFF7DD3FC)
                                },
                                fontSize = 13.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = slot.name,
                                    color = Color.White,
                                    fontSize = 12.5.sp,
                                    fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.SemiBold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = buildString {
                                        append(slot.category)
                                        if (slot.isImported && !slot.sourcePackName.isNullOrBlank()) {
                                            append(" · Pack: ${slot.sourcePackName}")
                                        } else if (isCustomizedFactory) {
                                            append(" · Custom Edited")
                                        }
                                    },
                                    color = if (isSelected) Color(0xFFE0F2FE) else Color(0xFF94A3B8),
                                    fontSize = 10.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                                if (isCustomizedFactory) {
                                    Button(
                                        onClick = { onRestoreOriginalPatch(slot.number) },
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF475569))
                                    ) {
                                        Text("Restore", fontSize = 10.sp)
                                    }
                                }
                                if (slot.isImported) {
                                    Button(
                                        onClick = { pendingDeletePatch = slot },
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7F1D1D))
                                    ) {
                                        Text("Delete", fontSize = 10.sp)
                                    }
                                }
                                Button(
                                    onClick = { onSelectPatch(slot.number) },
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (isSelected) Color(0xFF0369A1) else Color(0xFF0284C7)
                                    )
                                ) {
                                    Text(if (isSelected) "Loaded" else "Load", fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }

            PatchLoadTab.SAMPLES -> {
                // Multi-WAV & Multi-MP3 Pad Assignment Workspace
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 8.dp)
                ) {
                    Text(
                        text = "Assign imported WAV/MP3 samples to Active Patch (${activePatchNumber.toString().padStart(3, '0')}: ${activePatch.name}):",
                        color = Color(0xFFBAE6FD),
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.weight(1f)
                    )
                    Button(
                        onClick = {
                            importedSounds.take(8).forEachIndexed { idx, snd ->
                                onAssignSoundToPad(idx, snd)
                            }
                        },
                        enabled = importedSounds.isNotEmpty(),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7))
                    ) {
                        Text("Auto-Assign Top 8 to Pads", fontSize = 10.5.sp)
                    }
                    OutlinedTextField(
                        value = newPatchSaveName,
                        onValueChange = { newPatchSaveName = it.take(32) },
                        placeholder = { Text("New patch name...", fontSize = 10.5.sp) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = Color(0xFF38BDF8),
                            unfocusedBorderColor = Color(0xFF334155)
                        ),
                        modifier = Modifier.width(170.dp)
                    )
                    Button(
                        onClick = {
                            val title = newPatchSaveName.trim().ifBlank { "Phone Sample Kit" }
                            onSaveActivePadsAsImportedPatch(title)
                            newPatchSaveName = ""
                            onlyImportedFilter = true
                            activeTab = PatchLoadTab.LIBRARY
                        },
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF16A34A))
                    ) {
                        Text("Save as Imported Patch", fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
                    }
                }

                // Current 8 Pads Assignment Strip
                Row(
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 8.dp)
                ) {
                    activePatch.pads.forEach { pad ->
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(6.dp))
                                .background(Color(0xFF151E2C))
                                .border(1.dp, if (pad.customSoundId != null) Color(0xFF34D399) else Color(0xFF334155), RoundedCornerShape(6.dp))
                                .clickable { onPreviewSound(pad.sampleKey, pad.customSoundId, pad.volume, pad.pitch) }
                                .padding(6.dp)
                        ) {
                            Text("P${pad.padIndex + 1}", color = Color(0xFF7DD3FC), fontSize = 10.sp, fontWeight = FontWeight.ExtraBold)
                            Text(
                                text = pad.sampleName,
                                color = if (pad.customSoundId != null) Color(0xFF6EE7B7) else Color.White,
                                fontSize = 9.5.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }

                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(5.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                ) {
                    if (importedSounds.isEmpty()) {
                        item {
                            Text(
                                text = "No WAV or MP3 samples imported yet. Press 1. LOAD WAV SAMPLES or 2. LOAD MP3 SAMPLES above to select multiple audio files from your phone.",
                                color = Color(0xFF94A3B8),
                                fontSize = 12.sp,
                                modifier = Modifier.padding(16.dp)
                            )
                        }
                    }
                    items(importedSounds, key = { it.id }) { snd ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFF141D2B))
                                .border(1.dp, Color(0xFF263348), RoundedCornerShape(8.dp))
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Column(modifier = Modifier.weight(0.32f)) {
                                Text(snd.displayName, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text("${snd.fileName} · ${snd.durationMs} ms", color = Color(0xFF94A3B8), fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
                                Button(
                                    onClick = { onPreviewSound("custom", snd.id, 1.0f, 1.0f) },
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0F766E))
                                ) {
                                    Text("Preview", fontSize = 10.sp)
                                }
                                for (padIdx in 0..7) {
                                    val isAssignedHere = activePatch.pads.getOrNull(padIdx)?.customSoundId == snd.id
                                    Box(
                                        contentAlignment = Alignment.Center,
                                        modifier = Modifier
                                            .size(28.dp)
                                            .clip(RoundedCornerShape(5.dp))
                                            .background(if (isAssignedHere) Color(0xFF16A34A) else Color(0xFF1E293B))
                                            .border(1.dp, if (isAssignedHere) Color(0xFF86EFAC) else Color(0xFF3B82F6), RoundedCornerShape(5.dp))
                                            .clickable {
                                                onAssignSoundToPad(padIdx, snd)
                                                onPreviewSound("custom", snd.id, 0.95f, 1.0f)
                                            }
                                    ) {
                                        Text("P${padIdx + 1}", color = Color.White, fontSize = 9.5.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            PatchLoadTab.STAGED_IMPORT -> {
                val preview = phonePatchLoadUiState.stagedPreview
                if (preview == null) {
                    Column(
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.fillMaxWidth().weight(1f)
                    ) {
                        Text(
                            text = "No ZIP patch pack or JSON patch file staged yet.",
                            color = Color(0xFFCBD5E1),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(Modifier.height(6.dp))
                        Text(
                            text = "Press 3. LOAD ZIP PATCH PACK or 4. LOAD JSON PATCH FILE above to browse phone storage.",
                            color = Color(0xFF94A3B8),
                            fontSize = 11.5.sp
                        )
                    }
                } else {
                    // Import Preview Header + Complete Collection Load Action
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 6.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF151E2C))
                            .border(1.dp, Color(0xFF38BDF8), RoundedCornerShape(8.dp))
                            .padding(10.dp)
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "${preview.sourceType} IMPORT PREVIEW · ${preview.sourceName}",
                                color = Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.ExtraBold
                            )
                            Text(
                                text = "Found: ${preview.totalPatchesFound} patch(es) · Ready: ${preview.readyPatchesCount} · Decoded Audio: ${preview.extractedSounds.size} · Missing Samples: ${preview.missingSamples.size} · Failed: ${preview.failedPatches.size}",
                                color = if (preview.missingSamples.isNotEmpty()) Color(0xFFFCD34D) else Color(0xFF6EE7B7),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = { onCommitStagedPreview(null) },
                                enabled = preview.readyPatchesCount > 0,
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF16A34A))
                            ) {
                                Text("Load Collection (${preview.readyPatchesCount})", fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
                            }
                            Button(
                                onClick = onCancelStagedPreview,
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF334155))
                            ) {
                                Text("Cancel", fontSize = 11.sp, color = Color(0xFFFCA5A5))
                            }
                        }
                    }

                    // Missing Samples Explicit Resolution Bar
                    if (preview.missingSamples.isNotEmpty()) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 6.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFF451A03))
                                .border(1.dp, Color(0xFFF59E0B), RoundedCornerShape(8.dp))
                                .padding(8.dp)
                        ) {
                            Text(
                                text = "Missing Samples Detected (${preview.missingSamples.size}) — Select or replace missing files cleanly before importing:",
                                color = Color(0xFFFDE68A),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(Modifier.height(4.dp))
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                modifier = Modifier.horizontalScroll(rememberScrollState())
                            ) {
                                preview.missingSamples.forEach { fname ->
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(Color(0xFF78350F))
                                            .padding(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Text(fname, color = Color.White, fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
                                        Button(
                                            onClick = { onLaunchMissingSamplePicker(fname) },
                                            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7))
                                        ) {
                                            Text("Pick File", fontSize = 9.5.sp)
                                        }
                                        Button(
                                            onClick = { missingResolverTarget = fname },
                                            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B))
                                        ) {
                                            Text("Replace", fontSize = 9.5.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Staged Patches Breakdown List
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                    ) {
                        items(preview.stagedPatches, key = { it.localId }) { sp ->
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color(0xFF141D2B))
                                    .border(1.dp, if (sp.isReady) Color(0xFF22C55E).copy(alpha = 0.6f) else Color(0xFFF59E0B), RoundedCornerShape(8.dp))
                                    .padding(10.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = "${sp.name} (${sp.category})",
                                            color = Color.White,
                                            fontSize = 12.5.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = if (sp.isReady) "All 8 pads verified & ready to play" else "Missing: ${sp.missingFilenames.joinToString(", ")}",
                                            color = if (sp.isReady) Color(0xFF6EE7B7) else Color(0xFFFCD34D),
                                            fontSize = 10.5.sp
                                        )
                                    }
                                    Button(
                                        onClick = { onCommitStagedPreview(sp.localId) },
                                        enabled = sp.isReady,
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7))
                                    ) {
                                        Text("Import & Load Patch", fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                                Spacer(Modifier.height(6.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.fillMaxWidth()) {
                                    sp.pads.forEach { pad ->
                                        Box(
                                            modifier = Modifier
                                                .weight(1f)
                                                .clip(RoundedCornerShape(5.dp))
                                                .background(if (pad.isMissingSample) Color(0xFF7F1D1D) else Color(0xFF0F172A))
                                                .border(
                                                    1.dp,
                                                    if (pad.isMissingSample) Color(0xFFF87171) else Color(0xFF334155),
                                                    RoundedCornerShape(5.dp)
                                                )
                                                .clickable {
                                                    if (pad.isMissingSample && pad.expectedFilename != null) {
                                                        missingResolverTarget = pad.expectedFilename
                                                    } else {
                                                        onPreviewSound(pad.sampleKey, pad.customSoundId, pad.volume, pad.pitch)
                                                    }
                                                }
                                                .padding(4.dp)
                                        ) {
                                            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                                                Text("P${pad.padIndex + 1}", color = Color(0xFF7DD3FC), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                                Text(
                                                    text = pad.sampleName,
                                                    color = if (pad.isMissingSample) Color(0xFFFECACA) else Color.White,
                                                    fontSize = 9.sp,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        if (preview.failedPatches.isNotEmpty()) {
                            items(preview.failedPatches) { fail ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(Color(0xFF450A0A))
                                        .padding(8.dp)
                                ) {
                                    Text("Failed · ${fail.label}: ${fail.reason}", color = Color(0xFFFECACA), fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Confirmation Dialog for Deleting an Imported Patch
    pendingDeletePatch?.let { target ->
        AlertDialog(
            onDismissRequest = { pendingDeletePatch = null },
            title = { Text("Delete Imported Patch?") },
            text = {
                Text(
                    "Remove '${target.name}' (Slot ${target.number.toString().padStart(3, '0')}) from your imported patch library? Original 500 patches and bundled samples are unaffected."
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        onDeleteImportedPatch(target.number)
                        pendingDeletePatch = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626))
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { pendingDeletePatch = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Replacement Chooser Dialog for Missing Sample Filename
    missingResolverTarget?.let { missingFile ->
        AlertDialog(
            onDismissRequest = { missingResolverTarget = null },
            title = { Text("Resolve Missing Sample: $missingFile") },
            text = {
                Column(modifier = Modifier.height(240.dp)) {
                    Button(
                        onClick = {
                            missingResolverTarget = null
                            onLaunchMissingSamplePicker(missingFile)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                        modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
                    ) {
                        Text("Pick Replacement Audio File From Phone", fontSize = 11.5.sp)
                    }
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        items(importedSounds, key = { it.id }) { snd ->
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(Color(0xFF1E293B))
                                    .clickable {
                                        onResolveMissingWithSound(missingFile, snd)
                                        missingResolverTarget = null
                                    }
                                    .padding(8.dp)
                            ) {
                                Text("Custom: ${snd.displayName}", color = Color(0xFF6EE7B7), fontSize = 11.5.sp)
                            }
                        }
                        items(bundledLibrary, key = { it.key }) { b ->
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(Color(0xFF0F172A))
                                    .clickable {
                                        onResolveMissingWithBundled(missingFile, b)
                                        missingResolverTarget = null
                                    }
                                    .padding(8.dp)
                            ) {
                                Text("Original WAV: ${b.label}", color = Color(0xFFBAE6FD), fontSize = 11.5.sp)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { missingResolverTarget = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
private fun PhoneImportActionButton(
    label: String,
    containerColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Button(
        onClick = onClick,
        shape = RoundedCornerShape(7.dp),
        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 6.dp),
        colors = ButtonDefaults.buttonColors(containerColor = containerColor, contentColor = Color.White),
        modifier = modifier.height(38.dp)
    ) {
        Text(
            text = label,
            fontSize = 9.5.sp,
            fontWeight = FontWeight.ExtraBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}


