package com.mrkayluu.mroctapad

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.File
import java.util.UUID
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream

data class MultiAudioImportReport(
    val imported: List<ImportedSound>,
    val skippedReasons: List<String>
)

data class StagedPadEntry(
    val padIndex: Int,
    val expectedFilename: String?,
    val sampleKey: String,
    val sampleName: String,
    val customSoundId: String?,
    val volume: Float,
    val pitch: Float,
    val midiNote: Int,
    val isMissingSample: Boolean
)

data class StagedPatchEntry(
    val localId: String,
    val suggestedNumber: Int?,
    val name: String,
    val category: String,
    val sourcePackName: String?,
    val pads: List<StagedPadEntry>,
    val validationError: String? = null
) {
    val missingFilenames: List<String>
        get() = pads.filter { it.isMissingSample }
            .mapNotNull { it.expectedFilename }
            .distinct()

    val isReady: Boolean
        get() = validationError == null && missingFilenames.isEmpty()
}

data class FailedPatchEntry(
    val label: String,
    val reason: String
)

data class StagedImportPreview(
    val previewId: String,
    val sourceType: String, // "ZIP" or "JSON"
    val sourceName: String,
    val stagingDir: File?,
    val extractedSounds: List<ImportedSound>,
    val stagedPatches: List<StagedPatchEntry>,
    val failedPatches: List<FailedPatchEntry>
) {
    val totalPatchesFound: Int
        get() = stagedPatches.size + failedPatches.size

    val readyPatchesCount: Int
        get() = stagedPatches.count { it.isReady }

    val missingSamples: List<String>
        get() = stagedPatches.flatMap { it.missingFilenames }.distinct()
}

data class CommitImportResult(
    val totalPatchesFound: Int,
    val successfullyImported: List<PatchSlot>,
    val missingSamples: List<String>,
    val failedPatches: List<FailedPatchEntry>,
    val summaryMessage: String
)

class PhonePatchImporter(
    private val context: Context,
    private val storageManager: StorageManager,
    private val audioEngine: AudioEngine,
    private val patchManager: PatchManager,
    private val soundImportManager: SoundImportManager
) {
    private val maxZipUncompressedBytes = 180L * 1024L * 1024L
    private val maxZipEntries = 1000
    private val maxJsonBytes = 10L * 1024L * 1024L
    private val supportedAudioExts = setOf("wav", "mp3", "ogg")

    fun importMultipleAudioUris(
        uris: List<Uri>,
        expectedExtensionFilter: String? = null
    ): MultiAudioImportReport {
        val imported = mutableListOf<ImportedSound>()
        val skipped = mutableListOf<String>()

        uris.forEach { uri ->
            val displayName = queryDisplayName(uri)
            val ext = displayName.substringAfterLast('.', "").lowercase()
            if (expectedExtensionFilter != null && ext.isNotEmpty() && ext != expectedExtensionFilter &&
                !(expectedExtensionFilter == "mp3" && ext == "ogg")
            ) {
                // Still inspect MIME via importFromUri if valid audio, but warn clearly if non-audio
                val mime = context.contentResolver.getType(uri)?.lowercase() ?: ""
                if (!mime.startsWith("audio/") && ext !in supportedAudioExts) {
                    skipped.add("$displayName: Not a supported ${expectedExtensionFilter.uppercase()} audio file")
                    return@forEach
                }
            }
            val res = soundImportManager.importFromUri(uri)
            res.onSuccess { snd ->
                imported.add(snd)
            }.onFailure { err ->
                skipped.add("$displayName: ${err.message ?: "Decode failed"}")
            }
        }
        return MultiAudioImportReport(imported = imported, skippedReasons = skipped)
    }

    fun inspectZipPackUri(uri: Uri): Result<StagedImportPreview> {
        val displayName = queryDisplayName(uri)
        val packId = "pack_${UUID.randomUUID().toString().take(8)}"
        val packDir = File(storageManager.importedPacksDir, packId).apply { mkdirs() }

        return try {
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: Exception) {
            }

            val packCanonical = packDir.canonicalPath + File.separator
            val extractedAudioFiles = mutableListOf<Pair<String, File>>() // relPath -> private File
            val extractedJsonFiles = mutableListOf<Pair<String, File>>()
            val skippedEntries = mutableListOf<String>()
            var totalUncompressed = 0L
            var entryCount = 0

            val inputStream = context.contentResolver.openInputStream(uri)
                ?: run {
                    packDir.deleteRecursively()
                    return Result.failure(IllegalStateException("Unable to open ZIP archive from phone storage."))
                }

            BufferedInputStream(inputStream).use { bis ->
                bis.mark(4)
                val header = ByteArray(4)
                val readHeader = bis.read(header)
                bis.reset()
                if (readHeader < 4 || header[0] != 'P'.code.toByte() || header[1] != 'K'.code.toByte()) {
                    packDir.deleteRecursively()
                    return Result.failure(
                        IllegalArgumentException("Incompatible file '$displayName': Not a valid ZIP archive.")
                    )
                }

                ZipInputStream(bis).use { zis ->
                    val buf = ByteArray(16 * 1024)
                    var entry: ZipEntry? = zis.nextEntry
                    while (entry != null) {
                        entryCount++
                        if (entryCount > maxZipEntries) {
                            throw IllegalArgumentException("ZIP pack exceeds maximum limit of $maxZipEntries entries.")
                        }

                        val rawName = entry.name.replace('\\', '/')
                        // Reject path traversal & absolute entry names strictly
                        if (rawName.startsWith("/") || rawName.contains("..") || rawName.contains(":")) {
                            throw SecurityException("Blocked unsafe ZIP path entry: $rawName")
                        }

                        val cleanName = rawName.trimStart('/')
                        if (cleanName.isNotEmpty() &&
                            !cleanName.startsWith("__MACOSX/") &&
                            !cleanName.substringAfterLast('/').startsWith("._") &&
                            cleanName.substringAfterLast('/') != ".DS_Store"
                        ) {
                            val outFile = File(packDir, cleanName)
                            if (!outFile.canonicalPath.startsWith(packCanonical)) {
                                throw SecurityException("Blocked ZIP path traversal target: $cleanName")
                            }

                            if (entry.isDirectory) {
                                outFile.mkdirs()
                            } else {
                                outFile.parentFile?.mkdirs()
                                outFile.outputStream().use { fos ->
                                    while (true) {
                                        val r = zis.read(buf)
                                        if (r <= 0) break
                                        totalUncompressed += r
                                        if (totalUncompressed > maxZipUncompressedBytes) {
                                            throw IllegalArgumentException("ZIP pack exceeds safe 180 MB extraction limit.")
                                        }
                                        fos.write(buf, 0, r)
                                    }
                                    fos.flush()
                                }

                                val ext = outFile.extension.lowercase()
                                when {
                                    ext in supportedAudioExts -> extractedAudioFiles.add(cleanName to outFile)
                                    ext == "json" -> extractedJsonFiles.add(cleanName to outFile)
                                    else -> {
                                        outFile.delete()
                                        skippedEntries.add(cleanName)
                                    }
                                }
                            }
                        }
                        zis.closeEntry()
                        entry = zis.nextEntry
                    }
                }
            }

            if (extractedAudioFiles.isEmpty() && extractedJsonFiles.isEmpty()) {
                packDir.deleteRecursively()
                return Result.failure(
                    IllegalArgumentException(
                        "ZIP archive '$displayName' contains no supported WAV/MP3/OGG samples or JSON patch files."
                    )
                )
            }

            // Decode every extracted audio sample into AudioEngine immediately
            val extractedSounds = mutableListOf<ImportedSound>()
            val relPathToSound = mutableMapOf<String, ImportedSound>()
            val baseNameToSound = mutableMapOf<String, ImportedSound>()
            val stemToSound = mutableMapOf<String, ImportedSound>()

            extractedAudioFiles.forEach { (relPath, file) ->
                val soundId = "pack_${UUID.randomUUID().toString().take(8)}"
                val decodeRes = audioEngine.registerDecodedCustomSoundResult(soundId, file)
                decodeRes.onSuccess { durationMs ->
                    val fname = file.name
                    val cleanTitle = fname.substringBeforeLast('.').take(36).ifBlank { "Sample" }
                    val mime = when (file.extension.lowercase()) {
                        "mp3" -> "audio/mpeg"
                        "ogg" -> "audio/ogg"
                        else -> "audio/wav"
                    }
                    val snd = ImportedSound(
                        id = soundId,
                        displayName = cleanTitle,
                        fileName = fname,
                        filePath = file.absolutePath,
                        sourceUri = "zip://$displayName/$relPath",
                        mimeType = mime,
                        durationMs = durationMs
                    )
                    extractedSounds.add(snd)
                    relPathToSound[relPath.lowercase()] = snd
                    baseNameToSound.putIfAbsent(fname.lowercase(), snd)
                    stemToSound.putIfAbsent(cleanTitle.lowercase(), snd)
                }.onFailure {
                    skippedEntries.add("$relPath (corrupt/unsupported audio)")
                }
            }

            val existingSounds = soundImportManager.importedSounds.value
            val packLabel = displayName.substringBeforeLast('.').take(32).ifBlank { "ZIP Pack" }
            val stagedPatches = mutableListOf<StagedPatchEntry>()
            val failedPatches = mutableListOf<FailedPatchEntry>()

            if (extractedJsonFiles.isNotEmpty()) {
                extractedJsonFiles.forEach { (jsonRel, jsonFile) ->
                    val folderPrefix = jsonRel.substringBeforeLast('/', "").lowercase()
                    val jsonText = runCatching { jsonFile.readText() }.getOrElse {
                        failedPatches.add(FailedPatchEntry(jsonRel, "Could not read JSON text"))
                        return@forEach
                    }
                    val parsed = parseJsonPatchCollection(
                        rawJson = jsonText,
                        sourcePackName = packLabel,
                        folderPrefix = folderPrefix,
                        relPathToSound = relPathToSound,
                        baseNameToSound = baseNameToSound,
                        stemToSound = stemToSound,
                        existingSounds = existingSounds
                    )
                    stagedPatches.addAll(parsed.staged)
                    failedPatches.addAll(parsed.failed)
                }
            } else {
                // Auto-detect folder-based patch packs (each subfolder with audio files becomes a patch)
                val byFolder = extractedSounds.groupBy { snd ->
                    val rel = snd.sourceUri.removePrefix("zip://$displayName/")
                    rel.substringBeforeLast('/', packLabel).ifBlank { packLabel }
                }
                byFolder.entries.forEach { (folderName, soundsInFolder) ->
                    val cleanFolderTitle = folderName.substringAfterLast('/').ifBlank { packLabel }
                    soundsInFolder.chunked(8).forEachIndexed { chunkIdx, chunk ->
                        val title = if (soundsInFolder.size > 8) {
                            "$cleanFolderTitle Part ${chunkIdx + 1}"
                        } else {
                            cleanFolderTitle
                        }
                        val pads = (0 until 8).map { padIdx ->
                            val snd = chunk.getOrNull(padIdx)
                            if (snd != null) {
                                StagedPadEntry(
                                    padIndex = padIdx,
                                    expectedFilename = snd.fileName,
                                    sampleKey = "custom",
                                    sampleName = snd.displayName,
                                    customSoundId = snd.id,
                                    volume = 0.9f,
                                    pitch = 1.0f,
                                    midiNote = 36 + padIdx,
                                    isMissingSample = false
                                )
                            } else {
                                val fallback = patchManager.bundledLibrary[padIdx % patchManager.bundledLibrary.size]
                                StagedPadEntry(
                                    padIndex = padIdx,
                                    expectedFilename = null,
                                    sampleKey = fallback.key,
                                    sampleName = fallback.label,
                                    customSoundId = null,
                                    volume = 0.85f,
                                    pitch = 1.0f,
                                    midiNote = 36 + padIdx,
                                    isMissingSample = false
                                )
                            }
                        }
                        stagedPatches.add(
                            StagedPatchEntry(
                                localId = UUID.randomUUID().toString().take(8),
                                suggestedNumber = null,
                                name = title.take(36),
                                category = "ZIP Pack",
                                sourcePackName = packLabel,
                                pads = pads
                            )
                        )
                    }
                }
            }

            if (stagedPatches.isEmpty() && failedPatches.isNotEmpty()) {
                val reasons = failedPatches.joinToString("; ") { "${it.label}: ${it.reason}" }
                packDir.deleteRecursively()
                return Result.failure(IllegalArgumentException("Incompatible ZIP patch format: $reasons"))
            }

            if (stagedPatches.isEmpty() && extractedSounds.isEmpty()) {
                packDir.deleteRecursively()
                return Result.failure(IllegalArgumentException("No valid drum patches or audio samples found in ZIP."))
            }

            Result.success(
                StagedImportPreview(
                    previewId = packId,
                    sourceType = "ZIP",
                    sourceName = displayName,
                    stagingDir = packDir,
                    extractedSounds = extractedSounds,
                    stagedPatches = stagedPatches,
                    failedPatches = failedPatches
                )
            )
        } catch (e: SecurityException) {
            packDir.deleteRecursively()
            Result.failure(IllegalStateException(e.message ?: "Blocked unsafe ZIP archive.", e))
        } catch (e: Exception) {
            packDir.deleteRecursively()
            Result.failure(IllegalStateException("Invalid or incompatible ZIP pack: ${e.message ?: "Read failed"}", e))
        }
    }

    fun inspectJsonPatchUri(uri: Uri): Result<StagedImportPreview> {
        val displayName = queryDisplayName(uri)
        return try {
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: Exception) {
            }

            val bytes = context.contentResolver.openInputStream(uri)?.use { input ->
                val out = input.readBytes()
                if (out.size > maxJsonBytes) {
                    throw IllegalArgumentException("JSON patch file exceeds 10 MB limit.")
                }
                out
            } ?: return Result.failure(IllegalStateException("Unable to read JSON file from phone storage."))

            val rawJson = bytes.toString(Charsets.UTF_8).trim()
            if (rawJson.isEmpty()) {
                return Result.failure(IllegalArgumentException("Selected JSON file '$displayName' is empty."))
            }

            val packLabel = displayName.substringBeforeLast('.').take(32).ifBlank { "JSON Import" }
            val existingSounds = soundImportManager.importedSounds.value
            val parsed = parseJsonPatchCollection(
                rawJson = rawJson,
                sourcePackName = packLabel,
                folderPrefix = "",
                relPathToSound = emptyMap(),
                baseNameToSound = emptyMap(),
                stemToSound = emptyMap(),
                existingSounds = existingSounds
            )

            if (parsed.staged.isEmpty()) {
                val errDetail = parsed.failed.firstOrNull()?.reason
                    ?: "Unsupported JSON patch structure. Expected object/array of patches with 8 'pads'."
                return Result.failure(IllegalArgumentException("Compatibility error in '$displayName': $errDetail"))
            }

            Result.success(
                StagedImportPreview(
                    previewId = "json_${UUID.randomUUID().toString().take(8)}",
                    sourceType = "JSON",
                    sourceName = displayName,
                    stagingDir = null,
                    extractedSounds = emptyList(),
                    stagedPatches = parsed.staged,
                    failedPatches = parsed.failed
                )
            )
        } catch (e: Exception) {
            Result.failure(IllegalStateException("Could not parse JSON file '$displayName': ${e.message}", e))
        }
    }

    fun resolveMissingWithImportedSound(
        preview: StagedImportPreview,
        missingFilename: String,
        sound: ImportedSound
    ): StagedImportPreview {
        val target = missingFilename.lowercase()
        val updatedPatches = preview.stagedPatches.map { patch ->
            patch.copy(
                pads = patch.pads.map { pad ->
                    if (pad.isMissingSample && pad.expectedFilename?.lowercase() == target) {
                        pad.copy(
                            sampleKey = "custom",
                            sampleName = sound.displayName,
                            customSoundId = sound.id,
                            isMissingSample = false
                        )
                    } else pad
                }
            )
        }
        return preview.copy(stagedPatches = updatedPatches)
    }

    fun resolveMissingWithBundledSample(
        preview: StagedImportPreview,
        missingFilename: String,
        bundled: PatchManager.BundledSampleInfo
    ): StagedImportPreview {
        val target = missingFilename.lowercase()
        val updatedPatches = preview.stagedPatches.map { patch ->
            patch.copy(
                pads = patch.pads.map { pad ->
                    if (pad.isMissingSample && pad.expectedFilename?.lowercase() == target) {
                        pad.copy(
                            sampleKey = bundled.key,
                            sampleName = bundled.label,
                            customSoundId = null,
                            isMissingSample = false
                        )
                    } else pad
                }
            )
        }
        return preview.copy(stagedPatches = updatedPatches)
    }

    fun commitStagedPreview(
        preview: StagedImportPreview,
        singlePatchLocalId: String? = null
    ): CommitImportResult {
        if (preview.extractedSounds.isNotEmpty()) {
            soundImportManager.registerBatchImportedSounds(preview.extractedSounds)
        }

        val candidates = if (singlePatchLocalId != null) {
            preview.stagedPatches.filter { it.localId == singlePatchLocalId }
        } else {
            preview.stagedPatches
        }

        val missingFiles = candidates.flatMap { it.missingFilenames }.distinct()
        val allFailed = preview.failedPatches.toMutableList()

        val readyToCommit = mutableListOf<PatchSlot>()
        candidates.forEach { staged ->
            if (!staged.isReady) {
                val missingDesc = staged.missingFilenames.joinToString(", ")
                allFailed.add(FailedPatchEntry(staged.name, "Unresolved missing sample(s): $missingDesc"))
                return@forEach
            }
            val pads = staged.pads.mapIndexed { idx, p ->
                PadConfig(
                    padIndex = idx,
                    sampleKey = p.sampleKey,
                    sampleName = p.sampleName,
                    volume = p.volume,
                    pitch = p.pitch,
                    midiNote = p.midiNote,
                    customSoundId = p.customSoundId
                )
            }
            readyToCommit.add(
                PatchSlot(
                    number = 501,
                    name = staged.name,
                    category = staged.category,
                    pads = pads,
                    id = "imp_${UUID.randomUUID().toString().take(8)}",
                    isImported = true,
                    sourcePackName = staged.sourcePackName,
                    importedAtMs = System.currentTimeMillis()
                )
            )
        }

        val committed = patchManager.importPatchesCollection(readyToCommit, selectFirstImported = true)
        val summary = buildString {
            append("Found ${preview.totalPatchesFound} · Imported ${committed.size}")
            if (missingFiles.isNotEmpty()) append(" · Missing ${missingFiles.size} sample(s)")
            if (allFailed.isNotEmpty()) append(" · Skipped ${allFailed.size}")
        }

        return CommitImportResult(
            totalPatchesFound = preview.totalPatchesFound,
            successfullyImported = committed,
            missingSamples = missingFiles,
            failedPatches = allFailed,
            summaryMessage = summary
        )
    }

    fun cancelStagedPreview(preview: StagedImportPreview) {
        preview.stagingDir?.let { dir ->
            if (dir.exists()) {
                dir.deleteRecursively()
            }
        }
    }

    private data class ParsedJsonBatch(
        val staged: List<StagedPatchEntry>,
        val failed: List<FailedPatchEntry>
    )

    private fun parseJsonPatchCollection(
        rawJson: String,
        sourcePackName: String,
        folderPrefix: String,
        relPathToSound: Map<String, ImportedSound>,
        baseNameToSound: Map<String, ImportedSound>,
        stemToSound: Map<String, ImportedSound>,
        existingSounds: List<ImportedSound>
    ): ParsedJsonBatch {
        val trimmed = rawJson.trim()
        val patchObjects = mutableListOf<JSONObject>()
        val failed = mutableListOf<FailedPatchEntry>()
        var packTitle = sourcePackName

        try {
            if (trimmed.startsWith("[")) {
                val arr = JSONArray(trimmed)
                for (i in 0 until arr.length()) {
                    val item = arr.optJSONObject(i)
                    if (item != null) patchObjects.add(item)
                }
            } else if (trimmed.startsWith("{")) {
                val root = JSONObject(trimmed)
                packTitle = root.optString("packName", root.optString("collectionName", sourcePackName))
                    .ifBlank { sourcePackName }
                val arr = root.optJSONArray("patches")
                    ?: root.optJSONArray("kits")
                    ?: root.optJSONArray("collection")
                    ?: root.optJSONArray("items")
                if (arr != null) {
                    for (i in 0 until arr.length()) {
                        val item = arr.optJSONObject(i)
                        if (item != null) patchObjects.add(item)
                    }
                } else {
                    patchObjects.add(root)
                }
            } else {
                failed.add(FailedPatchEntry(sourcePackName, "File does not contain valid JSON object or array"))
                return ParsedJsonBatch(emptyList(), failed)
            }
        } catch (e: Exception) {
            failed.add(FailedPatchEntry(sourcePackName, "Malformed JSON syntax: ${e.message}"))
            return ParsedJsonBatch(emptyList(), failed)
        }

        if (patchObjects.isEmpty()) {
            failed.add(FailedPatchEntry(sourcePackName, "No patch definitions found in JSON"))
            return ParsedJsonBatch(emptyList(), failed)
        }

        val staged = mutableListOf<StagedPatchEntry>()
        val bundledKeys = patchManager.bundledLibrary.associateBy { it.key.lowercase() }
        val bundledLabels = patchManager.bundledLibrary.associateBy { it.label.lowercase() }
        val existingByFilename = existingSounds.associateBy { it.fileName.lowercase() }
        val existingByName = existingSounds.associateBy { it.displayName.lowercase() }
        val defaultNotes = listOf(36, 38, 42, 46, 45, 48, 49, 39)

        patchObjects.forEachIndexed { idx, obj ->
            val rawName = obj.optString("name", obj.optString("patchName", obj.optString("title", "")))
                .trim()
                .ifBlank { "$packTitle #${idx + 1}" }
            val suggestedNum = if (obj.has("number")) obj.optInt("number", -1).takeIf { it > 0 } else null
            val category = obj.optString("category", obj.optString("style", "Imported Phone"))
                .trim()
                .ifBlank { "Imported Phone" }

            val padsArr = obj.optJSONArray("pads")
            val padsMap = if (padsArr == null) obj.optJSONObject("pads") else null

            if (padsArr == null && padsMap == null) {
                failed.add(FailedPatchEntry(rawName, "Missing 'pads' array/object"))
                return@forEachIndexed
            }

            val parsedPads = mutableListOf<StagedPadEntry>()
            val rawPadObjs = Array<JSONObject?>(8) { null }

            if (padsArr != null) {
                for (i in 0 until padsArr.length()) {
                    val pObj = padsArr.optJSONObject(i) ?: continue
                    val rawIdx = when {
                        pObj.has("padIndex") -> pObj.optInt("padIndex", i)
                        pObj.has("pad") -> pObj.optInt("pad", i + 1) - 1
                        pObj.has("index") -> pObj.optInt("index", i)
                        else -> i
                    }
                    if (rawIdx in 0..7) {
                        rawPadObjs[rawIdx] = pObj
                    }
                }
            } else if (padsMap != null) {
                for (i in 0..7) {
                    rawPadObjs[i] = padsMap.optJSONObject(i.toString())
                        ?: padsMap.optJSONObject((i + 1).toString())
                        ?: padsMap.optJSONObject("pad${i + 1}")
                        ?: padsMap.optJSONObject("pad_${i + 1}")
                }
            }

            for (padIdx in 0..7) {
                val pObj = rawPadObjs[padIdx]
                if (pObj == null) {
                    val fallback = patchManager.bundledLibrary[padIdx % patchManager.bundledLibrary.size]
                    parsedPads.add(
                        StagedPadEntry(
                            padIndex = padIdx,
                            expectedFilename = null,
                            sampleKey = fallback.key,
                            sampleName = fallback.label,
                            customSoundId = null,
                            volume = 0.85f,
                            pitch = 1.0f,
                            midiNote = defaultNotes[padIdx],
                            isMissingSample = false
                        )
                    )
                    continue
                }

                val vol = pObj.optDouble("volume", 0.9).toFloat().coerceIn(0f, 1.4f)
                val pitch = pObj.optDouble("pitch", 1.0).toFloat().coerceIn(0.5f, 2.0f)
                val midi = pObj.optInt("midiNote", pObj.optInt("midi", defaultNotes[padIdx])).coerceIn(0, 127)

                val fileRef = pObj.optString("sampleFile", "")
                    .ifBlank { pObj.optString("filename", "") }
                    .ifBlank { pObj.optString("file", "") }
                    .ifBlank { pObj.optString("wav", "") }
                    .ifBlank { pObj.optString("mp3", "") }
                    .ifBlank { pObj.optString("sample", "") }
                    .trim()
                val explicitKey = pObj.optString("sampleKey", "").trim()
                val explicitLabel = pObj.optString("sampleName", "").trim()
                val explicitCustomId = if (pObj.has("customSoundId") && !pObj.isNull("customSoundId")) {
                    pObj.optString("customSoundId", "").trim()
                } else ""

                // Determine lookup candidate
                val normalizedRef = fileRef.replace('\\', '/').trimStart('/')
                val refBase = normalizedRef.substringAfterLast('/').lowercase()
                val refStem = refBase.substringBeforeLast('.').lowercase()

                val resolvedSound: ImportedSound? = when {
                    explicitCustomId.isNotEmpty() ->
                        existingSounds.firstOrNull { it.id == explicitCustomId }
                            ?: relPathToSound.values.firstOrNull { it.id == explicitCustomId }
                    normalizedRef.isNotEmpty() -> {
                        val withFolder = if (folderPrefix.isNotEmpty()) "$folderPrefix/${normalizedRef.lowercase()}" else normalizedRef.lowercase()
                        relPathToSound[withFolder]
                            ?: relPathToSound[normalizedRef.lowercase()]
                            ?: baseNameToSound[refBase]
                            ?: stemToSound[refStem]
                            ?: existingByFilename[refBase]
                            ?: existingByName[refStem]
                            ?: existingByName[normalizedRef.lowercase()]
                    }
                    explicitKey == "custom" && explicitLabel.isNotEmpty() -> {
                        existingByName[explicitLabel.lowercase()]
                            ?: stemToSound[explicitLabel.lowercase()]
                    }
                    else -> null
                }

                if (resolvedSound != null) {
                    parsedPads.add(
                        StagedPadEntry(
                            padIndex = padIdx,
                            expectedFilename = fileRef.ifBlank { resolvedSound.fileName },
                            sampleKey = "custom",
                            sampleName = explicitLabel.ifBlank { resolvedSound.displayName },
                            customSoundId = resolvedSound.id,
                            volume = vol,
                            pitch = pitch,
                            midiNote = midi,
                            isMissingSample = false
                        )
                    )
                } else if (fileRef.isEmpty() && explicitKey.isNotEmpty() && bundledKeys.containsKey(explicitKey.lowercase())) {
                    val b = bundledKeys[explicitKey.lowercase()]!!
                    parsedPads.add(
                        StagedPadEntry(
                            padIndex = padIdx,
                            expectedFilename = null,
                            sampleKey = b.key,
                            sampleName = explicitLabel.ifBlank { b.label },
                            customSoundId = null,
                            volume = vol,
                            pitch = pitch,
                            midiNote = midi,
                            isMissingSample = false
                        )
                    )
                } else if (fileRef.isNotEmpty() && bundledKeys.containsKey(fileRef.lowercase())) {
                    val b = bundledKeys[fileRef.lowercase()]!!
                    parsedPads.add(
                        StagedPadEntry(
                            padIndex = padIdx,
                            expectedFilename = null,
                            sampleKey = b.key,
                            sampleName = explicitLabel.ifBlank { b.label },
                            customSoundId = null,
                            volume = vol,
                            pitch = pitch,
                            midiNote = midi,
                            isMissingSample = false
                        )
                    )
                } else if (fileRef.isEmpty() && explicitLabel.isNotEmpty() && bundledLabels.containsKey(explicitLabel.lowercase())) {
                    val b = bundledLabels[explicitLabel.lowercase()]!!
                    parsedPads.add(
                        StagedPadEntry(
                            padIndex = padIdx,
                            expectedFilename = null,
                            sampleKey = b.key,
                            sampleName = b.label,
                            customSoundId = null,
                            volume = vol,
                            pitch = pitch,
                            midiNote = midi,
                            isMissingSample = false
                        )
                    )
                } else {
                    // Missing custom sample! Do NOT silently guess a bundled drum.
                    val missingLabel = fileRef.ifBlank {
                        explicitLabel.ifBlank { "pad_${padIdx + 1}_sample.wav" }
                    }
                    parsedPads.add(
                        StagedPadEntry(
                            padIndex = padIdx,
                            expectedFilename = missingLabel,
                            sampleKey = "custom",
                            sampleName = "MISSING: $missingLabel",
                            customSoundId = null,
                            volume = vol,
                            pitch = pitch,
                            midiNote = midi,
                            isMissingSample = true
                        )
                    )
                }
            }

            staged.add(
                StagedPatchEntry(
                    localId = UUID.randomUUID().toString().take(8),
                    suggestedNumber = suggestedNum,
                    name = rawName.take(36),
                    category = category,
                    sourcePackName = packTitle,
                    pads = parsedPads
                )
            )
        }

        return ParsedJsonBatch(staged = staged, failed = failed)
    }

    private fun queryDisplayName(uri: Uri): String {
        var name = uri.lastPathSegment?.substringAfterLast('/') ?: "phone_file"
        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0) {
                    name = cursor.getString(idx) ?: name
                }
            }
        }
        return name
    }
}
