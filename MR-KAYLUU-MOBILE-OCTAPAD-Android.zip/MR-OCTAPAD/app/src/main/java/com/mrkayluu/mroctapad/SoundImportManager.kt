package com.mrkayluu.mroctapad

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File
import java.util.UUID

class SoundImportManager(
    private val context: Context,
    private val storageManager: StorageManager,
    private val audioEngine: AudioEngine,
    private val patchManager: PatchManager
) {
    private val maxImportBytes = 50L * 1024L * 1024L // 50 MB safety cap

    private val _importedSounds = MutableStateFlow(storageManager.loadImportedSounds())
    val importedSounds: StateFlow<List<ImportedSound>> = _importedSounds.asStateFlow()

    fun importFromUri(uri: Uri): Result<ImportedSound> {
        return try {
            // Try persisting read permission where supported by the document provider
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: SecurityException) {
                // Provider may not offer persistable permission; private storage copy ensures durability
            } catch (_: UnsupportedOperationException) {
                // Non-persistable URI; private storage copy handles restoration
            }

            val meta = queryFileMetadata(uri)
            if (meta.sizeBytes > maxImportBytes) {
                return Result.failure(
                    IllegalArgumentException("File too large (${meta.sizeBytes / (1024 * 1024)} MB). Maximum supported sample size is 50 MB.")
                )
            }

            val ext = resolveExtension(meta.displayName, meta.mimeType)
            if (ext !in setOf("wav", "mp3", "ogg")) {
                return Result.failure(
                    IllegalArgumentException("Unsupported format (${meta.mimeType.ifBlank { ext }}). Please choose a WAV, MP3, or OGG file.")
                )
            }

            val id = "snd_${UUID.randomUUID().toString().take(8)}"
            val safeFileName = "${id}.${ext}"
            val destFile = File(storageManager.importedSoundsDir, safeFileName)

            val bytesCopied = copyUriToPrivateFile(uri, destFile)
            if (bytesCopied <= 0L) {
                destFile.delete()
                return Result.failure(IllegalStateException("Selected audio file could not be read or is empty."))
            }

            val decodeResult = audioEngine.registerDecodedCustomSoundResult(id, destFile)
            val durationMs = decodeResult.getOrElse { err ->
                destFile.delete()
                return Result.failure(err)
            }

            val cleanDisplayName = meta.displayName
                .substringBeforeLast('.')
                .take(36)
                .ifBlank { "Custom Sample" }

            val entry = ImportedSound(
                id = id,
                displayName = cleanDisplayName,
                fileName = safeFileName,
                filePath = destFile.absolutePath,
                sourceUri = uri.toString(),
                mimeType = meta.mimeType.ifBlank { "audio/$ext" },
                durationMs = durationMs
            )
            val updated = _importedSounds.value + entry
            _importedSounds.value = updated
            storageManager.saveImportedSounds(updated)
            Result.success(entry)
        } catch (e: SecurityException) {
            Result.failure(IllegalStateException("Permission denied reading audio file. Please pick the file again.", e))
        } catch (e: Exception) {
            Result.failure(IllegalStateException(e.message ?: "Failed to import audio sample.", e))
        }
    }

    fun previewSound(soundId: String) {
        audioEngine.previewCustomSound(soundId)
    }

    fun assignToPad(patchNumber: Int, padIndex: Int, sound: ImportedSound) {
        patchManager.assignSoundToPad(
            patchNumber = patchNumber,
            padIndex = padIndex,
            sampleKey = "custom",
            sampleName = sound.displayName,
            customSoundId = sound.id
        )
    }

    fun registerBatchImportedSounds(entries: List<ImportedSound>) {
        if (entries.isEmpty()) return
        val existingIds = _importedSounds.value.map { it.id }.toSet()
        val uniqueNew = entries.filterNot { it.id in existingIds }
        if (uniqueNew.isEmpty()) return
        val updated = _importedSounds.value + uniqueNew
        _importedSounds.value = updated
        storageManager.saveImportedSounds(updated)
    }

    fun deleteImportedSound(soundId: String) {
        val target = _importedSounds.value.firstOrNull { it.id == soundId } ?: return
        target.filePath.takeIf { it.isNotBlank() }?.let { File(it).delete() }
        File(storageManager.importedSoundsDir, target.fileName).delete()
        val next = _importedSounds.value.filterNot { it.id == soundId }
        _importedSounds.value = next
        storageManager.saveImportedSounds(next)
    }

    private fun copyUriToPrivateFile(uri: Uri, destFile: File): Long {
        var total = 0L
        context.contentResolver.openInputStream(uri)?.use { input ->
            destFile.outputStream().use { output ->
                val buffer = ByteArray(16 * 1024)
                while (true) {
                    val read = input.read(buffer)
                    if (read <= 0) break
                    total += read
                    if (total > maxImportBytes) {
                        throw IllegalArgumentException("Audio file exceeds the 50 MB import limit.")
                    }
                    output.write(buffer, 0, read)
                }
                output.flush()
            }
        } ?: throw IllegalStateException("Unable to open selected audio file from Android storage.")
        return total
    }

    private data class FileMeta(
        val displayName: String,
        val mimeType: String,
        val sizeBytes: Long
    )

    private fun queryFileMetadata(uri: Uri): FileMeta {
        var name = uri.lastPathSegment?.substringAfterLast('/') ?: "custom_sample.wav"
        var size = -1L
        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (nameIdx >= 0) {
                    name = cursor.getString(nameIdx) ?: name
                }
                val sizeIdx = cursor.getColumnIndex(OpenableColumns.SIZE)
                if (sizeIdx >= 0 && !cursor.isNull(sizeIdx)) {
                    size = cursor.getLong(sizeIdx)
                }
            }
        }
        val mime = context.contentResolver.getType(uri) ?: ""
        return FileMeta(displayName = name, mimeType = mime, sizeBytes = size)
    }

    private fun resolveExtension(name: String, mime: String): String {
        val byName = name.substringAfterLast('.', "").lowercase()
        if (byName in setOf("wav", "mp3", "ogg")) return byName
        val m = mime.lowercase()
        return when {
            m.contains("wav") || m.contains("wave") -> "wav"
            m.contains("mpeg") || m.contains("mp3") -> "mp3"
            m.contains("ogg") || m.contains("vorbis") -> "ogg"
            else -> byName
        }
    }
}
